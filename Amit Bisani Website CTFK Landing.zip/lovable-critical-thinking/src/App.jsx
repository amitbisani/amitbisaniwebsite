import { useEffect } from 'react';
import './index.css';

const PAGE_HTML = `
<!-- ============================ NAV ============================ -->
<header class="nav">
  <div class="wrap nav-inner">
    <a class="logo" href="#top" aria-label="Amit Bisani — home">
      <svg viewBox="0 0 3347.7 351.6" xmlns="http://www.w3.org/2000/svg">
        <path fill="#FF5B14" d="M186.43,263.12h-91.46l-12.71,43.04H0L97.99,45.44h87.88l97.97,260.72h-84.36l-13.04-43.04ZM169.72,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
        <path fill="#FF5B14" d="M309.62,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM390.9,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM390.9,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
        <rect fill="#FF5B14" x="679.5" width="27.35" height="351.6"/>
        <path fill="#F4EFE6" d="M995.97,263.12h-91.46l-12.71,43.04h-82.26l97.99-260.72h87.88l97.97,260.72h-84.36l-13.04-43.04ZM979.25,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
        <path fill="#F4EFE6" d="M1118.09,45.44h105.95l40.86,158.64,40.57-158.64h105.89v260.72h-65.98V107.33l-50.84,198.83h-59.72l-50.74-198.83v198.83h-65.98V45.44Z"/>
        <path fill="#F4EFE6" d="M1465.95,45.44h80.74v260.72h-80.74V45.44Z"/>
        <path fill="#F4EFE6" d="M1586.18,45.44h244.89v64.38h-82.16v196.34h-80.56V109.82h-82.16V45.44Z"/>
        <path fill="#F4EFE6" d="M1989.17,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM2070.44,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM2070.44,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
        <path fill="#F4EFE6" d="M2275.49,45.44h80.74v260.72h-80.74V45.44Z"/>
        <path fill="#F4EFE6" d="M2399.98,219.9l76.65-4.8c1.66,12.45,5.04,21.94,10.14,28.45,8.3,10.55,20.15,15.83,35.57,15.83,11.5,0,20.36-2.7,26.59-8.09,6.22-5.39,9.34-11.65,9.34-18.76s-2.96-12.8-8.89-18.14c-5.93-5.34-19.68-10.37-41.26-15.12-35.33-7.94-60.53-18.5-75.58-31.66-15.18-13.16-22.76-29.94-22.76-50.33,0-13.4,3.88-26.05,11.65-37.97,7.76-11.92,19.44-21.28,35.03-28.1,15.59-6.82,36.96-10.23,64.11-10.23,33.31,0,58.72,6.2,76.21,18.58,17.49,12.39,27.89,32.1,31.21,59.13l-75.94,4.45c-2.02-11.74-6.25-20.27-12.72-25.61-6.46-5.34-15.38-8-26.77-8-9.37,0-16.42,1.99-21.16,5.96-4.74,3.97-7.11,8.8-7.11,14.49,0,4.15,1.96,7.89,5.87,11.2,3.79,3.44,12.8,6.64,27.03,9.6,35.21,7.59,60.44,15.27,75.67,23.03,15.23,7.77,26.32,17.4,33.26,28.9,6.94,11.5,10.4,24.36,10.4,38.59,0,16.72-4.62,32.13-13.87,46.24-9.25,14.11-22.17,24.81-38.77,32.1-16.6,7.29-37.52,10.94-62.78,10.94-44.34,0-75.05-8.54-92.12-25.61-17.07-17.07-26.74-38.77-28.99-65.09Z"/>
        <path fill="#F4EFE6" d="M2837.35,263.12h-91.46l-12.71,43.04h-82.26l97.99-260.72h87.88l97.97,260.72h-84.36l-13.04-43.04ZM2820.63,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
        <path fill="#F4EFE6" d="M2960.9,45.44h75.23l98.17,144.24V45.44h75.94v260.72h-75.94l-97.64-143.15v143.15h-75.76V45.44Z"/>
        <path fill="#F4EFE6" d="M3266.96,45.44h80.74v260.72h-80.74V45.44Z"/>
      </svg>
    </a>
    <nav class="nav-links">
      <a href="#problem" data-spy="problem">The problem</a>
      <a href="#solution" data-spy="solution">The course</a>
      <a href="#curriculum" data-spy="curriculum">Curriculum</a>
      <a href="#reviews" data-spy="reviews">Reviews</a>
      <a href="#faq" data-spy="faq">FAQ</a>
    </nav>
    <div class="nav-cta">
      <a href="#enrol" class="btn btn-primary" style="height:40px;padding:0 16px;font-size:13px;">Enrol now <span class="px">· ₹1,499</span></a>
    </div>
  </div>
</header>

<span id="top"></span>

<!-- ============================ HERO ============================ -->
<section class="hero">
  <div class="blob" style="top:-160px; right:-120px; width:560px; height:560px; background:radial-gradient(circle,rgba(77,224,240,.4),transparent 62%);"></div>
  <div class="grain"></div>
  <div class="wrap hero-grid">
    <div class="reveal">
      <div style="display:flex; gap:9px; flex-wrap:wrap; margin-top:16px;">
        <span class="chip course"><span class="dot"></span> Video course · Parent-led</span>
        <span class="chip" style="color: rgb(255, 255, 255)">AGES 8–16</span>
      </div>
      <h1 class="display">Teach your kid to <span class="serif" style="color:var(--course);">think</span> — not just to score.</h1>
      <p class="sub">A 6-week, parent-led course that turns everyday conversations into a training ground for clear, independent thinking — for curious kids aged 8 to 14.</p>
      <div class="hero-cta">
        <a href="#enrol" class="btn btn-primary btn-lg">Enrol now <span class="px">· ₹1,499</span> <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>

      </div>
      <p class="hero-note" style="margin-top:16px;"><svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> One-time payment · lifetime access · 30-day money-back guarantee</p>

      <div class="trustbar">
        <div class="ti"><div class="tk">8–16</div><div class="tl">Age range</div></div>
        <div class="ti"><div class="tk">6 wks</div><div class="tl">Self-paced</div></div>
        <div class="ti"><div class="tk">2,400+</div><div class="tl">Families enrolled</div></div>
        <div class="ti"><div class="tk">30-day</div><div class="tl">Guarantee</div></div>
      </div>
    </div>

    <div class="hero-media reveal">
      <div class="video-card">
        <div class="ph placeholder">Course trailer · 90 sec<br/>drop video here</div>
        <div class="play"><button aria-label="Play trailer"><svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button></div>
        <div class="video-meta">
          <span class="tag">CTK01 · 24 LESSONS · 5H</span>
          <span class="tag" style="color:var(--course);">▶ WATCH</span>
        </div>
      </div>
      <div class="float-card float-1">
        <div class="eyebrow muted" style="font-size:9.5px;">Week 3 · today</div>
        <div style="font-size:12.5px; margin-top:5px; font-weight:500; color:var(--ab-ink-2);">"Mum, that's a <span style="color:var(--course);">false choice</span>." <br/><span style="color:var(--ab-ink-3);">— Aarav, age 10</span></div>
      </div>
      <div class="float-card float-2">
        <div style="display:flex; gap:3px; color:var(--ab-saffron); font-size:12px;">★★★★★</div>
        <div style="font-size:12px; margin-top:6px; color:var(--ab-ink-2); line-height:1.45;">"Best ₹1,499 I've spent on my daughter."<br/><span style="color:var(--ab-ink-3); font-size:10.5px;">— Sneha P., Pune</span></div>
      </div>
    </div>
  </div>
</section>

<!-- ====================== SOCIAL PROOF BAR ====================== -->
<section class="section tight" style="border-top:1px solid var(--ab-line);">
  <div class="wrap proofbar reveal" style="justify-content:center;">
    <div class="proof-l" style="justify-content:center;">
      <div>
        <div class="stars">★★★★★</div>
        <div style="font-size:13px; color:var(--ab-ink-3); margin-top:4px;"><strong style="color:var(--ab-ink); font-weight:600;">4.9</strong> from 2,400+ families</div>
      </div>
      <div class="rule" style="width:1px; height:40px;"></div>
      <div style="font-size:13.5px; color:var(--ab-ink-2); max-width:240px;">As trusted by parents across <strong style="color:var(--ab-ink); font-weight:600;">40+ Indian cities</strong> and the global diaspora.</div>
    </div>
  </div>
</section>

<!-- ========================= VSL ========================= -->
<section class="section" style="border-top:1px solid var(--ab-line);">
  <div class="wrap" style="max-width:900px;">
    <div class="section-head reveal" style="text-align:center; margin-bottom:40px;">
      <div class="eyebrow" style="text-align:center;">/ Watch this first</div>
      <h2 class="display" style="font-size:clamp(34px,4.8vw,60px); margin-top:12px;">The 3-minute idea that<br/><span class="serif" style="color:var(--course);">changes how your kid thinks.</span></h2>
      <p style="font-size:17px; color:var(--ab-ink-2); max-width:560px; margin:16px auto 0; line-height:1.55;">Press play. In a few minutes you will see exactly what your child learns each week — and why it sticks.</p>
    </div>
    <div class="reveal" style="position:relative; width:100%; aspect-ratio:16/9; background:var(--ab-surface-2); border:1px solid var(--ab-line-strong); border-radius:var(--r-xl); overflow:hidden; cursor:pointer;">
      <div class="grain"></div>
      <div style="position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); width:500px; height:500px; background:radial-gradient(circle,rgba(77,224,240,.15),transparent 65%); pointer-events:none;"></div>
      <div style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:28px;" id="vsl-cover">
        <div style="text-align:center;">
          <div class="mono" style="font-size:11px; letter-spacing:.16em; color:var(--ab-ink-3); margin-bottom:8px;">SALES VIDEO · VSL</div>
          <div class="display" style="font-size:32px; line-height:1.1;">VIDEO COMING SOON</div>
        </div>
        <button onclick="playVsl()" style="width:74px; height:74px; border-radius:999px; border:0; background:var(--ab-saffron); color:#1A0500; display:flex; align-items:center; justify-content:center; cursor:pointer; box-shadow:var(--glow-saffron); transition:transform .15s;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        </button>
      </div>
      <iframe id="vsl-iframe" src="" allow="autoplay" allowfullscreen style="position:absolute; inset:0; width:100%; height:100%; border:none; display:none;"></iframe>
      <div style="position:absolute; left:18px; bottom:18px;">
        <span class="mono" style="font-size:10.5px; letter-spacing:.1em; color:var(--ab-ink-2); background:rgba(11,9,8,.7); border:1px solid var(--ab-line); padding:6px 10px; border-radius:var(--r-pill); backdrop-filter:blur(6px);">FROM AMIT BISANI</span>
      </div>
      <div style="position:absolute; right:18px; bottom:18px;">
        <span class="mono" style="font-size:10.5px; letter-spacing:.1em; color:var(--course); background:rgba(11,9,8,.7); border:1px solid rgba(77,224,240,.3); padding:6px 10px; border-radius:var(--r-pill); backdrop-filter:blur(6px);">&#9654; WATCH</span>
      </div>
    </div>
    <p style="text-align:center; font-size:12.5px; color:var(--ab-ink-4); font-family:var(--ab-mono); letter-spacing:.08em; margin-top:14px;">3 MINUTES · WHAT YOUR CHILD LEARNS · WHY IT STICKS</p>
  </div>
</section>

<!-- ======================= TESTIMONIALS ======================= -->
<section class="section" id="reviews">
  <div class="wrap section-head reveal" style="display:flex; align-items:flex-end; justify-content:space-between; gap:24px; flex-wrap:wrap;">
    <div>
      <div class="eyebrow">/ the proof</div>
      <h2 class="display">Parents don't gush.<br/><span class="serif" style="color:#4de0f0;">Until their kid starts asking better questions.</span></h2>
    </div>
    <div style="text-align:right;">
      <div style="font-family:var(--ab-display); font-size:44px; font-weight:700; letter-spacing:-0.02em;">4.9 <span style="color:var(--ab-saffron); font-size:30px;">★</span></div>
      <div style="font-size:13px; color:var(--ab-ink-3);">averaged across 2,400+ families</div>
    </div>
  </div>

  <div class="tgrid-wrap reveal">
    <div class="tmarquee row1">
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"By week two my son started catching ads on TV — '<em>that's just an opinion, no?</em>' I nearly dropped my chai."</div><div class="tperson"><div class="avatar" style="background:var(--ab-saffron);">RM</div><div><div class="nm">Rohan M.</div><div class="ds">Father of two · Bengaluru</div></div></div></div>
      <div class="card wacard">
        <div class="wahead"><div class="avatar" style="background:var(--ab-cyan); width:32px; height:32px; font-size:12px;">SK</div><div><div style="font-size:12.5px; font-weight:600;">Shilpa K.</div><div style="font-size:10px; color:var(--ab-good);">online</div></div></div>
        <div class="bubble them">Did the "facts vs feelings" lesson at dinner 😅<span class="t">8:42 PM</span></div>
        <div class="bubble them">My 9yo corrected ME. Twice.<span class="t">8:42 PM</span></div>
        <div class="bubble me">That's exactly the point 🙂<span class="t">8:44 PM</span></div>
      </div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"I was worried it'd feel like extra homework. It's the opposite — it's the <em>one screen-time they ask for</em>."</div><div class="tperson"><div class="avatar" style="background:var(--ab-lime);">AV</div><div><div class="nm">Anjali V.</div><div class="ds">Mother · Hyderabad</div></div></div></div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"The 'steel-manning' week landed hard. My daughter now argues the <em>other</em> side first. In a 12-year-old. Unreal."</div><div class="tperson"><div class="avatar" style="background:var(--ab-violet);">DT</div><div><div class="nm">Deepak T.</div><div class="ds">Father · Delhi NCR</div></div></div></div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"Amit explains it for the parent, simply. I didn't need to be clever — I just needed to <em>show up at the table</em>."</div><div class="tperson"><div class="avatar" style="background:var(--ab-cyan);">MN</div><div><div class="nm">Meera N.</div><div class="ds">Mother of three · Chennai</div></div></div></div>
    </div>
    <div class="tmarquee row2">
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"School teaches him <em>what</em> to think. This finally taught him <em>how</em>. Worth every rupee."</div><div class="tperson"><div class="avatar" style="background:var(--ab-saffron-2);">KP</div><div><div class="nm">Karthik P.</div><div class="ds">Father · Kolkata</div></div></div></div>
      <div class="card wacard">
        <div class="wahead"><div class="avatar" style="background:var(--ab-saffron); width:32px; height:32px; font-size:12px;">NJ</div><div><div style="font-size:12.5px; font-weight:600;">Nikhil J.</div><div style="font-size:10px; color:var(--ab-good);">online</div></div></div>
        <div class="bubble them">Finished week 6 yesterday<span class="t">6:10 PM</span></div>
        <div class="bubble them">Genuinely changed how we talk as a family. Thank you 🙏<span class="t">6:11 PM</span></div>
        <div class="bubble me">This made my whole week ❤️<span class="t">6:30 PM</span></div>
      </div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"We're an NRI family. The activities work over video call with grandparents too. Unexpected bonus."</div><div class="tperson"><div class="avatar" style="background:var(--ab-lime);">PS</div><div><div class="nm">Priya S.</div><div class="ds">Mother · Dubai</div></div></div></div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"Calm, no fluff, no fear-mongering. Just <em>practical</em>. Exactly Amit's style from the podcast."</div><div class="tperson"><div class="avatar" style="background:var(--ab-cyan);">VG</div><div><div class="nm">Vikram G.</div><div class="ds">Father · Pune</div></div></div></div>
      <div class="card tcard"><div class="stars">★★★★★</div><div class="q">"My quiet kid started <em>debating</em> at the dinner table. I'll take it. Best parenting purchase this year."</div><div class="tperson"><div class="avatar" style="background:var(--ab-saffron);">RB</div><div><div class="nm">Ritu B.</div><div class="ds">Mother · Jaipur</div></div></div></div>
    </div>
  </div>
</section>

<!-- ==================== VIDEO TESTIMONIALS ==================== -->
<section class="section" id="video-reviews">
  <div class="wrap section-head reveal">
    <div class="eyebrow">/ what they have to say</div>
    <h2 class="display">Don't take our word for it.<br/><span class="serif" style="color:var(--course);">Hear it from the families themselves.</span></h2>
  </div>

  <div class="tgrid-wrap reveal" id="vtestimonials">
    <div class="vmarquee vrow1">
      <!-- cards injected by script (×2 for seamless loop) -->
    </div>
  </div>
</section>

<!-- ========================= PROBLEM ========================= -->
<section class="section" id="problem">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow saffron" style="color: rgb(77, 224, 240)">/ the problem</div>
      <h2 class="display">Your kid can ace the test<br/>and still believe anything.</h2>
      <p style="font-size:17px; color:var(--ab-ink-2); max-width:640px; margin-top:18px; line-height:1.55;">Marks measure memory. They don't measure whether your child can tell a fact from a feeling, spot a manipulative ad, or hold their ground in a room full of louder kids. That gap shows up later — and it shows up everywhere.</p>
    </div>
    <div class="pain-grid">
      <div class="card pain reveal"><div class="qmark">“</div><div><h4>"They believe whatever the group believes."</h4><p>One confident friend, one viral video, and your child's opinion flips. They haven't learned that "everyone says so" isn't a reason.</p></div></div>
      <div class="card pain reveal"><div class="qmark">“</div><div><h4>"They can't explain why they think something."</h4><p>Ask "why?" and you get a shrug or a "just because." The conclusion is there; the reasoning underneath it isn't.</p></div></div>
      <div class="card pain reveal"><div class="qmark">“</div><div><h4>"Screens are teaching them, and I can't see what."</h4><p>Hours of feeds, comments and clips — each one nudging. You can't audit all of it. But you can teach them to audit it themselves.</p></div></div>
      <div class="card pain reveal"><div class="qmark">“</div><div><h4>"They crumble the moment they're challenged."</h4><p>Push back gently and they fold — or dig in and shout. Neither is thinking. Both come from never having practised it safely.</p></div></div>
      <div class="card pain reveal"><div class="qmark">“</div><div><h4>"I want to help — but I don't know where to start."</h4><p>You're not a teacher and dinner is already chaos. You don't need a curriculum degree. You need a simple thing to do, tonight.</p></div></div>
    </div>
  </div>
</section>

<!-- ========================= SOLUTION ========================= -->
<section class="section" id="solution">
  <div class="blob" style="top:40px; left:-140px; width:420px; height:420px; background:radial-gradient(circle,rgba(77,224,240,.22),transparent 65%);"></div>
  <div class="wrap" style="position:relative; z-index:1;">
    <div class="solution-intro reveal">
      <div>
        <div class="eyebrow">/ the solution</div>
        <h2 class="display" style="font-size:clamp(36px,4.6vw,60px); margin-top:12px;">Critical Thinking<br/>for Kids.</h2>
      </div>
      <div>
        <p style="font-size:18px; color:var(--ab-ink-2); line-height:1.6;">A six-week course you do <em style="font-style:italic; font-family:var(--ab-serif); color:var(--course);">with</em> your child — not at them. Each week is one short video for you, one playful activity for them, and one dinner-table debrief that does the real work.</p>
        <p style="font-size:15px; color:var(--ab-ink-3); margin-top:16px; line-height:1.6;">No jargon. No worksheets to grade. No becoming the homework police. Just a calm, repeatable way to build the one skill school keeps forgetting to teach.</p>
      </div>
    </div>

    <div class="compare reveal">
      <div class="compare-col most">
        <h4>Most "kids courses"</h4>
        <div class="crow bad"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Park the kid in front of a screen, alone</div>
        <div class="crow bad"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Quizzes that reward memorising the "right" answer</div>
        <div class="crow bad"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Cartoonish, age-locked, outgrown in a month</div>
        <div class="crow bad"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Parent left out of the loop entirely</div>
        <div class="crow bad"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Ends when the videos end</div>
      </div>
      <div class="compare-col this">
        <h4>Critical Thinking for Kids</h4>
        <div class="crow"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> A shared ritual — you and your child, together</div>
        <div class="crow"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Real conversations that reward <em style="font-style:normal; color:var(--course);">reasoning</em></div>
        <div class="crow"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Age-grouped activities that grow 8 → 14</div>
        <div class="crow"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> You're coached too — in 12 minutes a week</div>
        <div class="crow"><svg class="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Becomes a habit that outlives the course</div>
      </div>
    </div>
  </div>
</section>

<!-- ====================== FREE LESSON OPT-IN ====================== -->
<section class="section optin" id="free-lesson">
  <div class="blob" style="top:-80px; right:-100px; width:420px; height:420px; background:radial-gradient(circle,rgba(77,224,240,.18),transparent 65%);"></div>
  <div class="grain"></div>
  <div class="wrap optin-inner" style="position:relative; z-index:1;">

    <div class="optin-copy reveal">
      <div class="eyebrow">/ free first lesson</div>
      <h2 class="display headline" style="margin-top:12px;">Try before you<br/><span class="serif" style="color:var(--course);">commit to anything.</span></h2>
      <p class="body">Let your child experience Lesson 1 — completely free. See how they respond, how it feels at the dinner table, and whether Amit's style clicks for your family. No credit card. No catch.</p>
      <div class="optin-perks">
        <div class="optin-perk">Instant access to first lesson (full lesson + activity)</div>
        <div class="optin-perk">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>
          A printable activity card for your child — ready for tonight
        </div>
        <div class="optin-perk">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>
          A short debrief guide so you know exactly what to say
        </div>
        <div class="optin-perk">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>
          Zero obligation — unlock the rest only if you love it
        </div>
      </div>
    </div>

    <div class="reveal">
      <div class="opt-form" id="opt-form-wrap">
        <div style="margin-bottom:24px;">
          <div class="eyebrow" style="color: rgb(77, 224, 240)">/ get free access</div>
          <div class="display" style="font-size:22px; margin-top:8px; letter-spacing:-0.02em;">First lesson, on us.</div>
        </div>

        <form id="opt-form" style="display:flex; flex-direction:column; gap:18px;" onsubmit="submitOptIn(event)">
          <div class="fgrid">
            <div class="frow">
              <label>Full Name <span style="color: rgb(77, 224, 240)">*</span></label>
              <input type="text" name="full_name" placeholder="e.g. Priya Sharma" required autocomplete="name" />
            </div>
            <div class="frow">
              <label>Email Address <span style="color: rgb(77, 224, 240)">*</span></label>
              <input type="email" name="email" placeholder="you@example.com" required autocomplete="email" />
            </div>
          </div>

          <div class="frow">
            <label>Phone — WhatsApp <span style="color: rgb(77, 224, 240)">*</span></label>
            <input type="tel" name="phone" placeholder="+91 98765 43210" required autocomplete="tel" />
          </div>

          <div class="frow">
            <label>What challenges is your child facing? <span style="color: rgb(77, 224, 240)">*</span></label>
            <textarea name="challenges" placeholder="e.g. Believes everything friends say, struggles to explain his thinking, gets upset when questioned..." required></textarea>
          </div>

          <button type="submit" class="btn btn-primary btn-lg btn-block" style="margin-top:4px;">
            Get Free Access to the First Lesson
            <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </button>

          <p class="fnote" style="text-align:center;">
            <svg class="svgi" style="width:12px;height:12px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l7 4v6c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-4z"/></svg>
            We respect your privacy. No spam, ever. Your details stay with Amit Bisani only.
          </p>
        </form>

        <div class="opt-success" id="opt-success">
          <div class="check">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>
          </div>
          <div>
            <div class="display" style="font-size:22px;">You're in!</div>
            <p style="font-size:14px; color:var(--ab-ink-2); margin-top:10px; line-height:1.6;">Check your inbox — Lesson 1 is on its way. Check WhatsApp too; Amit's team will share the activity card there. See you at the dinner table tonight.</p>
          </div>
          <a href="#enrol" class="btn btn-ghost" style="margin-top:6px;">Explore the full course →</a>
        </div>
      </div>
    </div>

  </div>
</section>

<!-- ======================= TRANSFORMATION ======================= -->
<section class="section">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow">/ the transformation</div>
      <h2 class="display">Six weeks from now.</h2>
    </div>
    <div class="ba reveal">
      <div class="ba-col now">
        <h4>Where they are now</h4>
        <div class="lead" style="color:var(--ab-ink-2);">Going along.</div>
        <ul>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg> Believes whatever's repeated most</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg> Answers "why?" with a shrug</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg> Folds — or shouts — when challenged</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg> Takes screens at face value</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg> Confuses "I feel" with "it's true"</li>
        </ul>
      </div>
      <div class="ba-mid"><div class="ba-arrow"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div></div>
      <div class="ba-col then">
        <h4>Where they'll be</h4>
        <div class="lead" style="color:var(--course);">Thinking for themselves.</div>
        <ul>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Asks "says who, and how do they know?"</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Explains <em style="font-style:normal; color:var(--course);">why</em> they think what they think</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Stays calm and curious under pushback</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Spots ads, spin and "everyone says"</li>
          <li><svg class="svgi" style="margin-top:3px;" viewBox="0 0 24 24" fill="none" stroke="var(--course)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Tells fact, opinion and feeling apart</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ========================= CURRICULUM ========================= -->
<section class="section" id="curriculum">
  <div class="wrap">
    <div class="section-head reveal" style="display:flex; align-items:flex-end; justify-content:space-between; gap:24px; flex-wrap:wrap;">
      <div>
        <div class="eyebrow">/ what's inside</div>
        <h2 class="display">Eleven lessons.<br/>One skill that outlasts school.</h2>
      </div>
      <span class="mono" style="font-size:11px; color:var(--ab-ink-3); letter-spacing:.1em;">11 LESSONS · 2H COURSE · PRINTABLE WORKBOOK</span>
    </div>

    <div class="acc reveal" id="curriculum-acc">
      <div class="acc-item open">
        <div class="acc-head"><span class="acc-wk">LESSON 01</span><span class="acc-title">What is Thinking?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Your child discovers the six types of thinking — logical, creative, analytical, concrete, reflective, and critical — through a vivid wave-board invention story. Each type gets a name and a real example, so the course feels like an adventure, not another subject.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 02</span><span class="acc-title">The Power of "Why?"</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">One small question changes everything. Ravi's curiosity about melting ice cream turns into a chain of five 'Why?' questions — unlocking lessons on heat, temperature, and solar energy. Your child's mission: ask at least five real questions this week and track where they lead.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 03</span><span class="acc-title">Logical Reasoning</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Your child becomes a Pattern Detective — spotting number sequences, shape patterns, fairy-tale structures, and daily cycles like traffic signals and seasons. Mission: find three real-life patterns, decode them, and share them with the family.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 04</span><span class="acc-title">Good vs Bad Decisions</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Every choice leads to pride or regret. Your child learns the 4-step formula — Stop &amp; Think, Consider Consequences, Evaluate Alternatives, Take Action &amp; Reflect — then practises it with real scenarios like copying a friend's homework or gaming instead of studying.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 05</span><span class="acc-title">Problem-Solving Skills</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">A 1,000-piece puzzle becomes manageable once you have a method. Your child learns the PLAY Formula (Problem → List → Act → Yay!) and applies it to a real 5-day science project — breaking one overwhelming task into clear, daily, conquerable steps.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 06</span><span class="acc-title">Don't Believe Everything You Hear</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Our brains love shortcuts — and that's exactly how misinformation spreads. Your child learns the four most common biases — Confirmation, Bandwagon, Stereotyping, and Media Bias — and practises spotting them using real headlines and everyday scenarios.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 07</span><span class="acc-title">Creative Thinking</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Velcro came from a dog walk; the Post-it Note from weak glue. Your child learns nine creative thinking tools — Mind Mapping, SCAMPER, Lateral Thinking, Reframing, Divergent Thinking, and more — to find solutions by looking at problems sideways, not straight ahead.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 08</span><span class="acc-title">Fact vs Opinion</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">"The Earth orbits the Sun" is a fact. "Summer is the best season" is an opinion. Your child learns to tell them apart in real conversations — spotting opinion words, checking multiple sources, and using fact-checking tools like Snopes before believing (or sharing) a claim.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 09</span><span class="acc-title">Persuasive Thinking</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">"Having a pet teaches responsibility" is a stronger argument than "pets are cute." Your child learns the three building blocks — Claim, Evidence, Counterargument — plus three persuasive tools: Logos (facts and data), Pathos (emotion), and Ethos (credibility).<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 10</span><span class="acc-title">Using Critical Thinking Daily</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">You make 35,000 decisions a day. Your child learns the THINK Fast Framework — Take a moment · Highlight facts vs opinions · Investigate perspectives · Note assumptions · Keep asking questions — applied to real situations: scam messages, purchases, time management, and more.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · 1 DEBRIEF</div></div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-wk">LESSON 11</span><span class="acc-title">Everyday Practice</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">The final lesson brings all ten skills together with a full recap — better questions, spotting bias, creative and persuasive thinking, and the THINK Fast Framework. Your child designs their own daily thinking routine and earns their Clear-Thinker certificate. Not an ending — a starting point.<div class="meta">1 LESSON · ~25 MIN · 1 ACTIVITY · CERTIFICATE</div></div></div>
      </div>
    </div>

    <div class="reveal" style="display:flex; justify-content:center; margin-top:34px;">
      <a href="#enrol" class="btn btn-primary btn-lg">Enrol &amp; start lesson one today <span class="px">· ₹1,499</span> <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

<!-- ======================== INSTRUCTOR ======================== -->
<section class="section">
  <div class="wrap instructor">
    <div class="reveal">
      <div class="portrait">
        <svg width="90%" height="90%" viewBox="0 0 100 100" style="position:absolute; bottom:0;">
          <path d="M5,100 C12,68 35,62 50,62 C65,62 88,68 95,100 Z" fill="#3A2418"/>
          <path d="M40,68 L40,55 L60,55 L60,68 Z" fill="#3A2418"/>
          <ellipse cx="50" cy="38" rx="20" ry="24" fill="#3A2418"/>
          <path d="M30,32 C30,18 40,12 50,12 C62,12 70,20 70,32 C70,28 65,22 60,22 C60,26 55,28 50,28 C45,28 40,26 40,22 C35,22 30,28 30,32 Z" fill="#0A0606"/>
          <path d="M34,42 C34,52 40,60 50,60 C60,60 66,52 66,42 C64,46 60,48 56,48 C55,52 53,54 50,54 C47,54 45,52 44,48 C40,48 36,46 34,42 Z" fill="#0A0606"/>
          <ellipse cx="50" cy="42" rx="9" ry="2" fill="#0A0606"/>
        </svg>
        <div class="placeholder" style="position:absolute; top:14px; left:14px; padding:5px 9px; border-radius:var(--r-pill); background:rgba(11,9,8,.5); border-style:solid; border-color:rgba(11,9,8,.3); color:rgba(11,9,8,.55);">instructor photo</div>
        <div class="badge"><div class="eyebrow muted" style="font-size:9.5px;">your coach</div><div style="font-weight:600; margin-top:3px; font-size:13.5px;">Amit Bisani · India</div></div>
      </div>
    </div>
    <div class="bio reveal">
      <div class="eyebrow">/ YOUR COACH</div>
      <h2 class="display" style="font-size:clamp(34px,4.2vw,52px); margin-top:12px;">I'm Amit.<br/><span class="serif" style="color:var(--course);">I help you keep your word to yourself.</span></h2>
      <p>My journey began in 2006 — but it was in 2017 that I found my true calling: cracking the code of effective goal-setting, productivity, and time management. I didn't get there by reading theory. I got there by coaching thousands of real people, watching what actually moves the needle, and building a methodology rooted in evidence, not assumption.</p>
      <p>Over the years, that mission has expanded into a wider practice of human transformation. I work on mindset mentoring and relationship coaching, helping people build inner clarity and stronger connections. I train aspiring speakers in the art of public speaking, and I work with children to sharpen critical thinking and communication skills early in life.</p>
      <p>My coaching style fuses inspiration, innovation, and practicality — creating an environment where aspirations aren't just set, but <strong style="color:var(--ab-ink);">achieved</strong>.</p>
      <div class="credstats" style="grid-template-columns:repeat(4,1fr);">
        <div class="cs"><div class="csk">9<span style="color: rgb(77, 224, 240)">+</span></div><div class="csl">Years coaching</div></div>
        <div class="cs"><div class="csk">14k<span style="color: rgb(77, 224, 240)">+</span></div><div class="csl">Learners impacted</div></div>
        <div class="cs"><div class="csk">20<span style="color: rgb(77, 224, 240)">+</span></div><div class="csl">Speaking events</div></div>
        <div class="cs"><div class="csk">4.9<span style="color: rgb(77, 224, 240)"> ★</span></div><div class="csl">Average rating</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ===================== BONUSES / VALUE STACK ===================== -->
<section class="section" id="enrol">
  <div class="blob" style="top:0; right:-120px; width:460px; height:460px; background:radial-gradient(circle,rgba(255,91,20,.2),transparent 65%);"></div>
  <div class="wrap" style="position:relative; z-index:1;">
    <div class="section-head reveal">
      <div class="eyebrow saffron" style="color: rgb(77, 224, 240)">/ everything you get</div>
      <h2 class="display">One enrolment.<br/>A whole toolkit.</h2>
    </div>
    <div class="stack">
      <div class="reveal">
        <div class="bonus"><div class="bi"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M23 7l-7 5 7 5V7zM2 7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7z"/></svg></div><div class="bt"><div class="bn">The full 6-week course</div><div class="bd">11 lessons · 2 hours of parent + kid video · lifetime access</div></div><div class="bv">₹1,499</div></div>
        <div class="bonus"><div class="bi"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zm0 0a2 2 0 0 1 2-2h13"/></svg></div><div class="bt"><div class="bn">Printable Thinking Workbook</div><div class="bd">Age-grouped activities and debrief cards</div></div><div class="bv">₹699</div></div>
        <div class="bonus"><div class="bi"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zm0 0a2 2 0 0 1 2-2h13"/></svg></div><div class="bt"><div class="bn">Bonus eBook · "Coaching Your Own Kid"</div><div class="bd">12 scripted conversations for car rides and dinners</div></div><div class="bv">₹399</div></div>
        <div class="bonus"><div class="bi"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></div><div class="bt"><div class="bn">The Parents' Circle on WhatsApp</div><div class="bd">A calm, moderated group of parents doing the same work</div></div><div class="bv">₹999</div></div>
        <div class="bonus"><div class="bi"><svg class="svgi" style="width:20px;height:20px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg></div><div class="bt"><div class="bn">Clear-Thinker certificate + lifetime updates</div><div class="bd">A printable certificate for your child, plus every future revision free</div></div><div class="bv">₹499</div></div>
      </div>

      <div class="card elevated stack-card reveal">
        <div class="chip course" style="margin-bottom:18px;"><span class="dot"></span> Founding price · one-time</div>
        <div class="totline"><span>Total real value</span><span class="v">₹4,595</span></div>
        <div class="total">
          <div>
            <div style="font-size:12px; color:var(--ab-ink-3);" class="mono">YOU PAY TODAY</div>
            <div class="stack-price">₹1,499</div>
          </div>
          <div class="v">₹4,595</div>
        </div>
        <a href="#" class="btn btn-primary btn-lg btn-block" style="margin-top:22px;">Enrol now <span class="px">· ₹1,499</span> <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        <div style="margin-top:14px; font-size:12px; color:var(--ab-ink-3); text-align:center; line-height:1.55;">UPI · Cards · Net banking · EMI<br/><span style="color:var(--ab-ink-2);">Instant access · 30-day money-back guarantee</span></div>
        <div class="rule" style="margin:18px 0;"></div>
        <div style="display:flex; gap:10px; align-items:flex-start; font-size:12.5px; color:var(--ab-ink-2);"><svg class="svgi" style="width:15px;height:15px;flex:none;margin-top:2px;" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> <span><strong style="color:var(--ab-ink); font-weight:600;">For:</strong> parents who want their child to think clearly, not just score well.</span></div>
      </div>
    </div>
  </div>
</section>

<!-- ========================= GUARANTEE ========================= -->
<section class="section guarantee">
  <div class="wrap gcard reveal">
    <div class="gseal"><svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l7 4v6c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-4z"/><path d="M9 12l2 2 4-4"/></svg></div>
    <div>
      <div class="eyebrow" style="color:var(--ab-lime);">/ zero risk</div>
      <h2 class="display" style="margin-top:12px;">Watch week one. If it doesn't change a single conversation, take your money back.</h2>
      <p>Go through the first week with your child. If you don't see them questioning, weighing and reasoning differently — or if it's just not for your family — email us within 30 days and we'll refund every rupee. No forms, no "why are you leaving" guilt trip. The bonuses are yours to keep.</p>
    </div>
  </div>
</section>

<!-- ============================ FAQ ============================ -->
<section class="section" id="faq">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow">/ before you ask</div>
      <h2 class="display">The honest answers.</h2>
    </div>
    <div class="acc faq reveal" id="faq-acc">
      <div class="acc-item open">
        <div class="acc-head"><span class="acc-faqn">01</span><span class="acc-title" style="font-size:18px;">How much time does it actually take each week?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">About 30 minutes, split up: a 12-minute video for you, a 10-minute activity for your child, and one short dinner-table debrief. It's self-paced, so you can do a week in one sitting or spread it across a few days — whatever fits your family.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">02</span><span class="acc-title" style="font-size:18px;">Will my child find it boring?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">It's built as games and real conversations, not lectures — spotting tricks in ads, friendly debates, "catch the grown-up" challenges. Most parents tell us it becomes the screen-time their kid actually asks for.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">03</span><span class="acc-title" style="font-size:18px;">My child is 8 (or 14). Is it really right for them?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Every activity comes in two versions — a simpler one for 8–10 and a deeper one for 11–14 — so the same lesson grows with your child. If you have kids at both ends, one enrolment covers the whole family.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">04</span><span class="acc-title" style="font-size:18px;">Do I have to be involved? I'm stretched thin.</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Yes — and that's the point, but it's light. The course coaches <em style="font-style:normal; color:var(--course);">you</em> in 12 minutes a week and hands you the exact words to use. You don't need to prepare or be an expert; you just need to show up at the table.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">05</span><span class="acc-title" style="font-size:18px;">Is this just going to make my kid argue more?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">The opposite, in our experience. Critical thinking done well makes kids <em style="font-style:normal; color:var(--course);">calmer</em> — they learn to ask instead of shout, to understand the other side, and to disagree without it becoming a fight. Week four is built entirely around this.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">06</span><span class="acc-title" style="font-size:18px;">How does access work? Is it forever?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">One payment, lifetime access — including every future update — on phone, tablet or laptop. Revisit it with a younger sibling in a few years at no extra cost.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">07</span><span class="acc-title" style="font-size:18px;">What if it's not right for us?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Email us within 30 days for a full, no-questions refund — and keep the bonuses. There's genuinely no risk in trying week one.</div></div>
      </div>
      <div class="acc-item">
        <div class="acc-head"><span class="acc-faqn">08</span><span class="acc-title" style="font-size:18px;">Can I pay in instalments?</span><span class="acc-plus"><svg class="svgi" style="width:15px;height:15px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
        <div class="acc-body"><div class="inner">Yes — no-cost EMI is available on most cards at checkout, alongside UPI and net banking. International parents can pay by card in USD.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- ========================= URGENCY ========================= -->
<section class="section urgency">
  <div class="wrap urgband reveal">
    <div>
      <div class="eyebrow saffron" style="color: rgb(77, 224, 240)">/ founding cohort</div>
      <h3 class="display" style="font-size:clamp(26px,3vw,38px); margin-top:10px;">Founding price ends soon.</h3>
      <p style="font-size:14px; color:var(--ab-ink-3); margin-top:10px; max-width:420px;">The launch group locks in ₹1,499 <em style="font-style:normal; color:var(--ab-ink-2);">and</em> the full bonus stack. After it fills, the price goes up and the WhatsApp Circle closes to new parents.</p>
      <div class="seats" style="margin-top:20px;">
        <div class="seatbar"><i style="background-color: rgb(77, 224, 240)"></i></div>
        <span class="mono" style="font-size:11.5px; color:var(--ab-ink-2);">39 / 50 seats taken</span>
      </div>
    </div>
    <div style="text-align:center;">
      <div class="mono" style="font-size:10.5px; letter-spacing:.14em; color:var(--ab-ink-3); margin-bottom:12px;">FOUNDING PRICE ENDS IN</div>
      <div class="countdown" id="countdown">
        <div class="cdcell"><div class="cdn" data-cd="d">02</div><div class="cdl">Days</div></div>
        <div class="cdcell"><div class="cdn" data-cd="h">11</div><div class="cdl">Hours</div></div>
        <div class="cdcell"><div class="cdn" data-cd="m">45</div><div class="cdl">Mins</div></div>
        <div class="cdcell"><div class="cdn" data-cd="s">08</div><div class="cdl">Secs</div></div>
      </div>
      <a href="#enrol" class="btn btn-primary" style="margin-top:20px;">Lock in ₹1,499 <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

<!-- ========================= FINAL CTA ========================= -->
<section class="section close">
  <div class="blob" style="bottom:-160px; left:50%; transform:translateX(-50%); width:680px; height:480px; background:radial-gradient(circle,rgba(255,91,20,.22),transparent 65%);"></div>
  <div class="grain"></div>
  <div class="wrap reveal" style="position:relative; z-index:1;">
    <div class="eyebrow saffron" style="text-align: center; color: rgb(77, 224, 240)">/ two paths</div>
    <h2 class="display" style="margin-top:16px;">In six weeks, your child<br/>is six weeks <span class="serif" style="color:#4de0f0;">older.</span></h2>
    <p style="font-size:17px; color:var(--ab-ink-2); max-width:600px; margin:20px auto 0; line-height:1.55;">The only question is whether they spend those weeks learning to think for themselves — or learning to go along. You get to choose that today.</p>

    <div class="paths">
      <div class="path a">
        <div class="pl">Path one · do nothing</div>
        <div class="pt">Hope they figure it out.</div>
        <p>The feeds keep teaching. The questions keep not getting asked. Maybe it works out. Maybe you wonder, later, why you waited.</p>
      </div>
      <div class="path b" style="border-color: rgba(77, 224, 240, 0.3)">
        <div class="pl" style="color: rgb(77, 224, 240)">Path two · start this week</div>
        <div class="pt" style="color: rgb(77, 224, 240)">Give them the habit, on purpose.</div>
        <p style="color: rgb(77, 224, 240)">30 minutes a week, six weeks, and a way of thinking that quietly protects them for the rest of their life. Starting tonight.</p>
      </div>
    </div>

    <div class="close-cta">
      <a href="#enrol" class="btn btn-primary btn-lg" style="height:60px; padding:0 38px; font-size:17px;">Enrol in Critical Thinking for Kids <span class="px">· ₹1,499</span> <svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      <a href="#" style="font-size:13.5px; color:var(--ab-ink-3); text-decoration:underline; text-underline-offset:3px;">Not sure yet? Book a free 15-min call →</a>
    </div>

    <div class="close-trust">
      <span><svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> 30-day money-back guarantee</span>
      <span><svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> Lifetime access · all updates free</span>
      <span><svg class="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg> 2,400+ families · 4.9 ★</span>
    </div>
  </div>
</section>

<!-- ============================ FOOTER ============================ -->
<footer class="foot">
  <div class="wrap foot-inner">
    <a class="logo" href="#top" style="opacity:.9;">
      <svg viewBox="0 0 580 351.6" xmlns="http://www.w3.org/2000/svg" style="height:22px;width:auto;display:block;">
        <path fill="#FF5B14" d="M186.43,263.12h-91.46l-12.71,43.04H0L97.99,45.44h87.88l97.97,260.72h-84.36l-13.04-43.04ZM169.72,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
        <path fill="#FF5B14" d="M309.62,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM390.9,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM390.9,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
      </svg>
    </a>
    <div class="foot-links">
      <a href="#">Contact</a>
      <a href="#">Terms of Service</a>
      <a href="#">Cancellation &amp; Refund</a>
      <a href="#">Privacy Policy</a>
    </div>
    <div class="mono" style="font-size:10.5px; color:var(--ab-ink-4); letter-spacing:.08em;">© 2026 Amit Bisani</div>
  </div>
</footer>

<!-- ===================== STICKY MOBILE BAR ===================== -->
<div class="mbar" id="mbar">
  <div class="mb-t">
    <div class="mb-n">Critical Thinking for Kids</div>
    <div class="mb-p">One-time · lifetime access</div>
  </div>
  <a href="#enrol" class="btn btn-primary" style="height:42px;">Enrol · ₹1,499</a>
</div>
`;

export default function App() {
  useEffect(() => {
    document.documentElement.classList.add('js');
    (function(){
      /* ---------- video testimonials ---------- */
      var vpeople = [
        {nm:'Rohan Mehta', ds:'Father of two · Bengaluru'},
        {nm:'Shilpa Kaur', ds:'Mother · Delhi'},
        {nm:'Anjali Verma', ds:'Mother · Hyderabad'},
        {nm:'Deepak Tiwari', ds:'Father · Delhi NCR'},
        {nm:'Meera Nair', ds:'Mother of three · Chennai'},
        {nm:'Karthik Pillai', ds:'Father · Kolkata'}
      ];
      var vrow = document.querySelector('#vtestimonials .vmarquee');
      if(vrow && !vrow.children.length){
        function makeCard(p, i){
          var c = document.createElement('div');
          c.className = 'vcard';
          c.dataset.slot = i;
          c.innerHTML =
            '<div class="vph"><div class="vlabel">Video '+(i+1)+'</div><div class="vsub">9:16 vertical · upload parent clip</div></div>'
            + '<video preload="metadata" playsinline></video>'
            + '<button class="vupload" type="button">Upload</button>'
            + '<div class="vplay"></div>'
            + '<div class="vfoot"><div class="vnm">'+p.nm+'</div><div class="vds">'+p.ds+'</div></div>';
          var video = c.querySelector('video');
          var input = document.createElement('input');
          input.type='file'; input.accept='video/*'; input.style.display='none';
          c.appendChild(input);
          var key = 'ct_vtest_'+i;
          try{ var saved = localStorage.getItem(key); if(saved){ video.src = saved; c.classList.add('has-video'); } }catch(e){}
          c.querySelector('.vupload').addEventListener('click', function(ev){ ev.stopPropagation(); input.click(); });
          input.addEventListener('change', function(){
            var f = input.files && input.files[0]; if(!f) return;
            var rd = new FileReader();
            rd.onload = function(){ video.src = rd.result; c.classList.add('has-video');
              try{ localStorage.setItem(key, rd.result); }catch(e){} };
            rd.readAsDataURL(f);
          });
          c.addEventListener('click', function(){
            if(!video.src) { input.click(); return; }
            if(video.paused){
              document.querySelectorAll('#vtestimonials video').forEach(function(v){ if(v!==video){ v.pause(); v.closest('.vcard').classList.remove('playing'); } });
              video.play(); c.classList.add('playing');
            } else { video.pause(); c.classList.remove('playing'); }
          });
          video.addEventListener('ended', function(){ c.classList.remove('playing'); });
          return c;
        }
        for(var rep=0; rep<2; rep++){
          vpeople.forEach(function(p,i){ vrow.appendChild(makeCard(p,i)); });
        }
      }
    })();
    (function(){
      /* ---------- reveal on scroll ---------- */
      var reveals = Array.prototype.slice.call(document.querySelectorAll('.reveal'));
      function forceShow(){ reveals.forEach(function(r){ r.classList.add('show-now'); }); }
      function inView(el){ var r = el.getBoundingClientRect(); return r.top < (window.innerHeight || 0) && r.bottom > 0; }
      if('IntersectionObserver' in window){
        var io = new IntersectionObserver(function(entries){
          entries.forEach(function(e){
            if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
          });
        }, { threshold:0.08, rootMargin:'0px 0px -6% 0px' });
        /* let the hidden base state paint, then start observing + reveal what's already on-screen */
        requestAnimationFrame(function(){ requestAnimationFrame(function(){
          reveals.forEach(function(r){ io.observe(r); });
          reveals.forEach(function(r){ if(inView(r)){ r.classList.add('in'); io.unobserve(r); } });
        }); });
        /* safety net: force-show any element that is on-screen yet still hidden
           (covers contexts where the keyframe animation never paints) */
        setTimeout(function(){
          reveals.forEach(function(r){
            if(!r.classList.contains('show-now') && inView(r) && getComputedStyle(r).opacity === '0'){
              r.classList.add('show-now');
            }
          });
        }, 1500);
      } else {
        forceShow();
      }
    
      /* ---------- accordions ---------- */
      function setBody(item){
        var body = item.querySelector('.acc-body');
        if(item.classList.contains('open')){ body.style.maxHeight = body.scrollHeight + 'px'; }
        else { body.style.maxHeight = '0px'; }
      }
      document.querySelectorAll('.acc').forEach(function(acc){
        acc.querySelectorAll('.acc-item').forEach(function(item){ setBody(item); });
        acc.addEventListener('click', function(e){
          var head = e.target.closest('.acc-head');
          if(!head) return;
          var item = head.parentElement;
          var wasOpen = item.classList.contains('open');
          acc.querySelectorAll('.acc-item').forEach(function(it){ it.classList.remove('open'); setBody(it); });
          if(!wasOpen){ item.classList.add('open'); setBody(item); }
        });
      });
      window.addEventListener('resize', function(){
        document.querySelectorAll('.acc-item.open').forEach(setBody);
      });
    
      /* ---------- scroll-spy nav ---------- */
      var spyLinks = Array.prototype.slice.call(document.querySelectorAll('.nav-links a[data-spy]'));
      var sections = spyLinks.map(function(a){ return document.getElementById(a.getAttribute('data-spy')); }).filter(Boolean);
      function onScroll(){
        var pos = window.scrollY + 120;
        var current = null;
        sections.forEach(function(sec){ if(sec.offsetTop <= pos) current = sec.id; });
        spyLinks.forEach(function(a){ a.classList.toggle('active', a.getAttribute('data-spy') === current); });
        /* backup reveal: any reveal scrolled into view gets shown even if the observer is dead */
        reveals.forEach(function(r){ if(!r.classList.contains('in') && inView(r)) r.classList.add('in'); });
      }
    
      /* ---------- sticky mobile bar ---------- */
      var mbar = document.getElementById('mbar');
      var enrol = document.getElementById('enrol');
      function onScrollBar(){
        var show = window.scrollY > 640;
        // hide once the pricing/enrol section is on screen to avoid covering its CTA
        if(enrol){
          var r = enrol.getBoundingClientRect();
          if(r.top < window.innerHeight && r.bottom > 0) show = false;
        }
        mbar.classList.toggle('show', show);
      }
    
      var ticking = false;
      window.addEventListener('scroll', function(){
        if(!ticking){ window.requestAnimationFrame(function(){ onScroll(); onScrollBar(); ticking = false; }); ticking = true; }
      }, { passive:true });
      onScroll(); onScrollBar();
    
      /* ---------- countdown ---------- */
      var KEY = 'ctk_deadline';
      var deadline = parseInt(localStorage.getItem(KEY) || '0', 10);
      var now = Date.now();
      if(!deadline || deadline < now){
        deadline = now + (2*24*3600 + 11*3600 + 45*60 + 8) * 1000; /* ~2d 11h 45m */
        localStorage.setItem(KEY, String(deadline));
      }
      var cd = { d:document.querySelector('[data-cd="d"]'), h:document.querySelector('[data-cd="h"]'), m:document.querySelector('[data-cd="m"]'), s:document.querySelector('[data-cd="s"]') };
      function pad(n){ return (n<10?'0':'')+n; }
      function tick(){
        var diff = Math.max(0, deadline - Date.now());
        var t = Math.floor(diff/1000);
        var d = Math.floor(t/86400); t-=d*86400;
        var h = Math.floor(t/3600); t-=h*3600;
        var m = Math.floor(t/60); var s = t-m*60;
        if(cd.d){ cd.d.textContent=pad(d); cd.h.textContent=pad(h); cd.m.textContent=pad(m); cd.s.textContent=pad(s); }
      }
      tick(); setInterval(tick, 1000);
    
      /* ---------- opt-in form ---------- */
      window.submitOptIn = function(e){
        e.preventDefault();
        var form = document.getElementById('opt-form');
        var btn = form.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Sending…';
        /* simulate async submit — wire to your backend / Zapier / ConvertKit here */
        setTimeout(function(){
          form.style.display = 'none';
          var success = document.getElementById('opt-success');
          success.style.display = 'flex';
        }, 900);
      };
    
      /* ---------- VSL ---------- */
      window.playVsl = function(){
        var cover = document.getElementById('vsl-cover');
        var iframe = document.getElementById('vsl-iframe');
        /* set iframe.src to your video embed URL when ready */
        cover.style.display = 'none';
        iframe.style.display = 'block';
      };
    })();
  }, []);

  return <div dangerouslySetInnerHTML={{ __html: PAGE_HTML }} />;
}
