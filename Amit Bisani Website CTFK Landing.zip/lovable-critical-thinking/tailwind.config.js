/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        'ab-bg': '#0B0908',
        'ab-surface-1': '#141110',
        'ab-surface-2': '#1C1816',
        'ab-surface-3': '#262220',
        'ab-line': '#2A2522',
        'ab-line-strong': '#3A332E',
        'ab-ink': '#F4EFE6',
        'ab-ink-2': '#C9C0B2',
        'ab-ink-3': '#8A8175',
        'ab-ink-4': '#5C544A',
        'ab-saffron': '#FF5B14',
        'ab-saffron-2': '#FF8042',
        'ab-saffron-deep': '#C53D00',
        'ab-lime': '#E8FF4D',
        'ab-crimson': '#FF3D5A',
        'ab-violet': '#7A5CFF',
        'ab-cyan': '#4DE0F0',
        'ab-good': '#4ADE80',
        course: '#4DE0F0',
      },
      fontFamily: {
        serif: ['"Instrument Serif"', '"Times New Roman"', 'serif'],
        sans: ['Geist', 'Manrope', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        display: ['"Bricolage Grotesque"', 'Geist', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      borderRadius: { sm: '6px', md: '10px', lg: '14px', xl: '20px', '2xl': '28px', pill: '999px' },
      maxWidth: { site: '1240px' },
      boxShadow: { 'glow-saffron': '0 0 0 1px rgba(255,91,20,.4),0 8px 36px -8px rgba(255,91,20,.55)' },
    },
  },
  plugins: [],
};
