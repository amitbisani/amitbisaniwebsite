# Critical Thinking for Kids — Amit Bisani (React / Vite / Tailwind)

A React port of the Critical Thinking for Kids landing page, ready to import into Lovable.

## Run locally
```
npm install
npm run dev
```

## Import into Lovable
1. Push this folder to a GitHub repo (it's the repo root).
2. In Lovable: **New Project → Import from GitHub**, and select the repo.

Lovable's native stack is React + Vite + Tailwind — this project matches it.

## Structure
- `tailwind.config.js` — design tokens as Tailwind utilities: colors (`ab-bg`, `ab-saffron`, `course` = cyan #4DE0F0, …), fonts (`font-display`, `font-serif`, `font-mono`), radii (`rounded-pill`, `rounded-xl`, …) and `shadow-glow-saffron`.
- `src/index.css` — Tailwind directives (`base` / `components` / `utilities`) plus the page's own component CSS, kept verbatim for pixel fidelity.
- `src/App.jsx` — the page. Markup is mounted as one HTML template; all interactivity (reveal-on-scroll, accordions, countdown, scroll-spy, video-testimonial uploads, opt-in form, VSL) runs in a single `useEffect`. Ask Lovable to "split App.jsx into JSX section components" to break it up.
- Fonts load from Google Fonts in `index.html`.

## Notes
- Forms and CTAs are front-end only — wire the opt-in form (`window.submitOptIn`) and Enrol buttons to your backend / checkout.
- The VSL and course-trailer are placeholders; set the iframe / video `src` to your embeds.
- The instructor portrait and trailer use drop-in placeholders — replace with real assets.
