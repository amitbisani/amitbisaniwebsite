import { useEffect } from 'react';
import './index.css';

export default function App() {
  useEffect(() => {
    document.documentElement.classList.add('js');
    (function(){
      /* ---------- video testimonials ---------- */
      var vpeople = [
        {nm:'Aarti Desai', ds:'Marketing lead · Mumbai'},
        {nm:'Sanjay Iyer', ds:'Founder · Bengaluru'},
        {nm:'Neha Kulkarni', ds:'Consultant · Pune'},
        {nm:'Rahul Verma', ds:'Engineer · Gurgaon'},
        {nm:'Pooja Nair', ds:'Operations · Chennai'},
        {nm:'Arjun Mehta', ds:'Product manager · Hyderabad'}
      ];
      var vrow = document.querySelector('#vtestimonials .vmarquee');
      if(vrow && vrow.children.length) vrow = null;
      if(vrow){
        function makeCard(p, i){
          var c = document.createElement('div');
          c.className = 'vcard';
          c.dataset.slot = i;
          c.innerHTML =
            '<div class="vph"><div class="vlabel">Video '+(i+1)+'</div><div class="vsub">9:16 vertical · upload student clip</div></div>'
            + '<video preload="metadata" playsinline></video>'
            + '<button class="vupload" type="button">Upload</button>'
            + '<div class="vplay"></div>'
            + '<div class="vfoot"><div class="vnm">'+p.nm+'</div><div class="vds">'+p.ds+'</div></div>';
          var video = c.querySelector('video');
          var input = document.createElement('input');
          input.type='file'; input.accept='video/*'; input.style.display='none';
          c.appendChild(input);
          var key = 'tm_vtest_'+i;
          try{ var saved = localStorage.getItem(key); if(saved){ video.src = saved; c.classList.add('has-video'); } }catch(e){}
          c.querySelector('.vupload').addEventListener('click', function(ev){ ev.stopPropagation(); input.click(); });
          input.addEventListener('change', function(){
            var f = input.files && input.files[0]; if(!f) return;
            var rd = new FileReader();
            rd.onload = function(){ video.src = rd.result; c.classList.add('has-video');
              try{ localStorage.setItem(key, rd.result); }catch(e){} };
            rd.readAsDataURL(f);
          });
          c.addEventListener('click', function(){
            if(!video.src) { input.click(); return; }
            if(video.paused){
              // pause any others
              document.querySelectorAll('#vtestimonials video').forEach(function(v){ if(v!==video){ v.pause(); v.closest('.vcard').classList.remove('playing'); } });
              video.play(); c.classList.add('playing');
            } else { video.pause(); c.classList.remove('playing'); }
          });
          video.addEventListener('ended', function(){ c.classList.remove('playing'); });
          return c;
        }
        // build twice for seamless marquee loop
        for(var rep=0; rep<2; rep++){
          vpeople.forEach(function(p,i){ vrow.appendChild(makeCard(p,i)); });
        }
      }
    })();
    (function(){
      /* ---------- reveal on scroll ---------- */
      var reveals = Array.prototype.slice.call(document.querySelectorAll('.reveal'));
      function forceShow(){ reveals.forEach(function(r){ r.classList.add('show-now'); }); }
      function inView(el){ var r = el.getBoundingClientRect(); return r.top < (window.innerHeight || 0) && r.bottom > 0; }
      if('IntersectionObserver' in window){
        var io = new IntersectionObserver(function(entries){
          entries.forEach(function(e){
            if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
          });
        }, { threshold:0.08, rootMargin:'0px 0px -6% 0px' });
        /* let the hidden base state paint, then start observing + reveal what's already on-screen */
        requestAnimationFrame(function(){ requestAnimationFrame(function(){
          reveals.forEach(function(r){ io.observe(r); });
          reveals.forEach(function(r){ if(inView(r)){ r.classList.add('in'); io.unobserve(r); } });
        }); });
        /* safety net: force-show any element that is on-screen yet still hidden
           (covers contexts where the keyframe animation never paints) */
        setTimeout(function(){
          reveals.forEach(function(r){
            if(!r.classList.contains('show-now') && inView(r) && getComputedStyle(r).opacity === '0'){
              r.classList.add('show-now');
            }
          });
        }, 1500);
      } else {
        forceShow();
      }
    
      /* ---------- accordions ---------- */
      function setBody(item){
        var body = item.querySelector('.acc-body');
        if(item.classList.contains('open')){ body.style.maxHeight = body.scrollHeight + 'px'; }
        else { body.style.maxHeight = '0px'; }
      }
      document.querySelectorAll('.acc').forEach(function(acc){
        acc.querySelectorAll('.acc-item').forEach(function(item){ setBody(item); });
        acc.addEventListener('click', function(e){
          var head = e.target.closest('.acc-head');
          if(!head) return;
          var item = head.parentElement;
          var wasOpen = item.classList.contains('open');
          acc.querySelectorAll('.acc-item').forEach(function(it){ it.classList.remove('open'); setBody(it); });
          if(!wasOpen){ item.classList.add('open'); setBody(item); }
        });
      });
      window.addEventListener('resize', function(){
        document.querySelectorAll('.acc-item.open').forEach(setBody);
      });
    
      /* ---------- scroll-spy nav ---------- */
      var spyLinks = Array.prototype.slice.call(document.querySelectorAll('.nav-links a[data-spy]'));
      var sections = spyLinks.map(function(a){ return document.getElementById(a.getAttribute('data-spy')); }).filter(Boolean);
      function onScroll(){
        var pos = window.scrollY + 120;
        var current = null;
        sections.forEach(function(sec){ if(sec.offsetTop <= pos) current = sec.id; });
        spyLinks.forEach(function(a){ a.classList.toggle('active', a.getAttribute('data-spy') === current); });
        /* backup reveal: any reveal scrolled into view gets shown even if the observer is dead */
        reveals.forEach(function(r){ if(!r.classList.contains('in') && inView(r)) r.classList.add('in'); });
      }
    
      /* ---------- sticky mobile bar ---------- */
      var mbar = document.getElementById('mbar');
      var enrol = document.getElementById('enrol');
      function onScrollBar(){
        var show = window.scrollY > 640;
        // hide once the pricing/enrol section is on screen to avoid covering its CTA
        if(enrol){
          var r = enrol.getBoundingClientRect();
          if(r.top < window.innerHeight && r.bottom > 0) show = false;
        }
        mbar.classList.toggle('show', show);
      }
    
      var ticking = false;
      window.addEventListener('scroll', function(){
        if(!ticking){ window.requestAnimationFrame(function(){ onScroll(); onScrollBar(); ticking = false; }); ticking = true; }
      }, { passive:true });
      onScroll(); onScrollBar();
    
      /* ---------- countdown ---------- */
      var KEY = 'tm_deadline';
      var deadline = parseInt(localStorage.getItem(KEY) || '0', 10);
      var now = Date.now();
      if(!deadline || deadline < now){
        deadline = now + (2*24*3600 + 11*3600 + 45*60 + 8) * 1000; /* ~2d 11h 45m */
        localStorage.setItem(KEY, String(deadline));
      }
      var cd = { d:document.querySelector('[data-cd="d"]'), h:document.querySelector('[data-cd="h"]'), m:document.querySelector('[data-cd="m"]'), s:document.querySelector('[data-cd="s"]') };
      function pad(n){ return (n<10?'0':'')+n; }
      function tick(){
        var diff = Math.max(0, deadline - Date.now());
        var t = Math.floor(diff/1000);
        var d = Math.floor(t/86400); t-=d*86400;
        var h = Math.floor(t/3600); t-=h*3600;
        var m = Math.floor(t/60); var s = t-m*60;
        if(cd.d){ cd.d.textContent=pad(d); cd.h.textContent=pad(h); cd.m.textContent=pad(m); cd.s.textContent=pad(s); }
      }
      tick(); setInterval(tick, 1000);
    
      /* ---------- opt-in form ---------- */
      window.submitOptIn = function(e){
        e.preventDefault();
        var form = document.getElementById('opt-form');
        var btn = form.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Sending…';
        /* simulate async submit — wire to your backend / Zapier / ConvertKit here */
        setTimeout(function(){
          form.style.display = 'none';
          var success = document.getElementById('opt-success');
          success.style.display = 'flex';
        }, 900);
      };
    
      /* ---------- VSL ---------- */
      window.playVsl = function(){
        var cover = document.getElementById('vsl-cover');
        var iframe = document.getElementById('vsl-iframe');
        /* set iframe.src to your video embed URL when ready */
        cover.style.display = 'none';
        iframe.style.display = 'block';
      };
    })();
    
      /* --- React bindings for former inline handlers --- */
      (function(){
        var f = document.getElementById('opt-form');
        if(f && window.submitOptIn) f.addEventListener('submit', window.submitOptIn);
        var cover = document.getElementById('vsl-cover');
        var pb = cover && cover.querySelector('button');
        if(pb && window.playVsl) pb.addEventListener('click', window.playVsl);
      })();
  }, []);

  return (
    <>
      <header className="nav">
        <div className="wrap nav-inner">
          <a className="logo" href="#top" aria-label="Amit Bisani — home">
            <svg viewBox="0 0 3347.7 351.6" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FF5B14" d="M186.43,263.12h-91.46l-12.71,43.04H0L97.99,45.44h87.88l97.97,260.72h-84.36l-13.04-43.04ZM169.72,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
              <path fill="#FF5B14" d="M309.62,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM390.9,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM390.9,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
              <rect fill="#FF5B14" x="679.5" width="27.35" height="351.6"/>
              <path fill="#F4EFE6" d="M995.97,263.12h-91.46l-12.71,43.04h-82.26l97.99-260.72h87.88l97.97,260.72h-84.36l-13.04-43.04ZM979.25,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
              <path fill="#F4EFE6" d="M1118.09,45.44h105.95l40.86,158.64,40.57-158.64h105.89v260.72h-65.98V107.33l-50.84,198.83h-59.72l-50.74-198.83v198.83h-65.98V45.44Z"/>
              <path fill="#F4EFE6" d="M1465.95,45.44h80.74v260.72h-80.74V45.44Z"/>
              <path fill="#F4EFE6" d="M1586.18,45.44h244.89v64.38h-82.16v196.34h-80.56V109.82h-82.16V45.44Z"/>
              <path fill="#F4EFE6" d="M1989.17,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM2070.44,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM2070.44,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
              <path fill="#F4EFE6" d="M2275.49,45.44h80.74v260.72h-80.74V45.44Z"/>
              <path fill="#F4EFE6" d="M2399.98,219.9l76.65-4.8c1.66,12.45,5.04,21.94,10.14,28.45,8.3,10.55,20.15,15.83,35.57,15.83,11.5,0,20.36-2.7,26.59-8.09,6.22-5.39,9.34-11.65,9.34-18.76s-2.96-12.8-8.89-18.14c-5.93-5.34-19.68-10.37-41.26-15.12-35.33-7.94-60.53-18.5-75.58-31.66-15.18-13.16-22.76-29.94-22.76-50.33,0-13.4,3.88-26.05,11.65-37.97,7.76-11.92,19.44-21.28,35.03-28.1,15.59-6.82,36.96-10.23,64.11-10.23,33.31,0,58.72,6.2,76.21,18.58,17.49,12.39,27.89,32.1,31.21,59.13l-75.94,4.45c-2.02-11.74-6.25-20.27-12.72-25.61-6.46-5.34-15.38-8-26.77-8-9.37,0-16.42,1.99-21.16,5.96-4.74,3.97-7.11,8.8-7.11,14.49,0,4.15,1.96,7.89,5.87,11.2,3.79,3.44,12.8,6.64,27.03,9.6,35.21,7.59,60.44,15.27,75.67,23.03,15.23,7.77,26.32,17.4,33.26,28.9,6.94,11.5,10.4,24.36,10.4,38.59,0,16.72-4.62,32.13-13.87,46.24-9.25,14.11-22.17,24.81-38.77,32.1-16.6,7.29-37.52,10.94-62.78,10.94-44.34,0-75.05-8.54-92.12-25.61-17.07-17.07-26.74-38.77-28.99-65.09Z"/>
              <path fill="#F4EFE6" d="M2837.35,263.12h-91.46l-12.71,43.04h-82.26l97.99-260.72h87.88l97.97,260.72h-84.36l-13.04-43.04ZM2820.63,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
              <path fill="#F4EFE6" d="M2960.9,45.44h75.23l98.17,144.24V45.44h75.94v260.72h-75.94l-97.64-143.15v143.15h-75.76V45.44Z"/>
              <path fill="#F4EFE6" d="M3266.96,45.44h80.74v260.72h-80.74V45.44Z"/>
            </svg>
          </a>
          <nav className="nav-links">
            <a href="#problem" data-spy="problem">The problem</a>
            <a href="#solution" data-spy="solution">The course</a>
            <a href="#curriculum" data-spy="curriculum">Curriculum</a>
            <a href="#reviews" data-spy="reviews">Reviews</a>
            <a href="#faq" data-spy="faq">FAQ</a>
          </nav>
          <div className="nav-cta">
            <a href="#enrol" className="btn btn-primary" style={{height: "40px", padding: "0 16px", fontSize: "13px"}}>Enrol now <span className="px">· ₹1,499</span></a>
          </div>
        </div>
      </header>
      
      <span id="top"></span>
      
      
      <section className="hero">
        <div className="blob" style={{top: "-160px", right: "-120px", width: "560px", height: "560px", background: "radial-gradient(circle,rgba(255,91,20,.4),transparent 62%)"}}></div>
        <div className="grain"></div>
        <div className="wrap hero-grid">
          <div className="reveal">
            <div style={{display: "flex", gap: "9px", flexWrap: "wrap", marginTop: "16px"}}>
              <span className="chip course"><span className="dot"></span> Video course · Self-paced</span>
              <span className="chip" style={{color: "rgb(255, 255, 255)"}}>FOR WORKING PROFESSIONALS</span>
            </div>
            <h1 className="display">Finish the day with something <span className="serif" style={{color: "var(--course)"}}>actually</span> done.</h1>
            <p className="sub">A 4-week, self-paced course for people whose calendars look full but whose week looks empty — the no-fluff system that moved the needle for 2600+ coaching clients.</p>
            <div className="hero-cta">
              <a href="#enrol" className="btn btn-primary btn-lg">Enrol now <span className="px">· ₹1,499</span> <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      
            </div>
            <p className="hero-note" style={{marginTop: "16px"}}><svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> One-time payment · lifetime access · 30-day money-back guarantee</p>
      
            <div className="trustbar">
              <div className="ti"><div className="tk">4 wks</div><div className="tl">Self-paced</div></div>
              <div className="ti"><div className="tk">18</div><div className="tl">Lessons · 3 hrs</div></div>
              <div className="ti"><div className="tk">2600+</div><div className="tl">Clients coached</div></div>
              <div className="ti"><div className="tk">30-day</div><div className="tl">Guarantee</div></div>
            </div>
          </div>
      
          <div className="hero-media reveal">
            <div className="video-card">
              <div className="ph placeholder">Course trailer · 90 sec<br/>drop video here</div>
              <div className="play"><button aria-label="Play trailer"><svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button></div>
              <div className="video-meta">
                <span className="tag">TM01 · 6 MODULES · 15 LESSONS</span>
                <span className="tag" style={{color: "var(--course)"}}>▶ WATCH</span>
              </div>
            </div>
            <div className="float-card float-1">
              <div className="eyebrow muted" style={{fontSize: "9.5px"}}>Week 1 · the audit</div>
              <div style={{fontSize: "12.5px", marginTop: "5px", fontWeight: "500", color: "var(--ab-ink-2)"}}>"I found <span style={{color: "var(--course)"}}>9 hours a week</span> I didn't know I had." <br/><span style={{color: "var(--ab-ink-3)"}}>— Arjun, product lead</span></div>
            </div>
            <div className="float-card float-2">
              <div style={{display: "flex", gap: "3px", color: "var(--ab-saffron)", fontSize: "12px"}}>★★★★★</div>
              <div style={{fontSize: "12px", marginTop: "6px", color: "var(--ab-ink-2)", lineHeight: "1.45"}}>"Best ₹1,499 I've invested on my own time."
      — Sneha P., Pune</div>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section tight" style={{borderTop: "1px solid var(--ab-line)"}}>
        <div className="wrap proofbar reveal" style={{justifyContent: "center"}}>
          <div className="proof-l" style={{justifyContent: "center"}}>
            <div>
              <div className="stars">★★★★★</div>
              <div style={{fontSize: "13px", color: "var(--ab-ink-3)", marginTop: "4px"}}><strong style={{color: "var(--ab-ink)", fontWeight: "600"}}>4.9</strong> from 2,400+ professionals</div>
            </div>
            <div className="rule" style={{width: "1px", height: "40px"}}></div>
            <div style={{fontSize: "13.5px", color: "var(--ab-ink-2)", maxWidth: "240px"}}>Trusted by founders, managers and solo operators across <strong style={{color: "var(--ab-ink)", fontWeight: "600"}}>40+ Indian cities</strong> and the global diaspora.</div>
          </div>
        </div>
      </section>
      
      
      <section className="section" style={{borderTop: "1px solid var(--ab-line)"}}>
        <div className="wrap" style={{maxWidth: "900px"}}>
          <div className="section-head reveal" style={{textAlign: "center", marginBottom: "40px"}}>
            <div className="eyebrow" style={{textAlign: "center"}}>/ Watch this first</div>
            <h2 className="display" style={{fontSize: "clamp(34px,4.8vw,60px)", marginTop: "12px"}}>The 3-minute idea that<br/><span className="serif" style={{color: "var(--course)"}}>gives you your week back.</span></h2>
            <p style={{fontSize: "17px", color: "var(--ab-ink-2)", maxWidth: "560px", margin: "16px auto 0", lineHeight: "1.55"}}>Press play. In a few minutes you'll see exactly how the system works each week — and why it finally sticks.</p>
          </div>
          <div className="reveal" style={{position: "relative", width: "100%", aspectRatio: "16/9", background: "var(--ab-surface-2)", border: "1px solid var(--ab-line-strong)", borderRadius: "var(--r-xl)", overflow: "hidden", cursor: "pointer"}}>
            <div className="grain"></div>
            <div style={{position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: "500px", height: "500px", background: "radial-gradient(circle,rgba(255,91,20,.15),transparent 65%)", pointerEvents: "none"}}></div>
            <div style={{position: "absolute", inset: "0", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "28px"}} id="vsl-cover">
              <div style={{textAlign: "center"}}>
                <div className="mono" style={{fontSize: "11px", letterSpacing: ".16em", color: "var(--ab-ink-3)", marginBottom: "8px"}}>SALES VIDEO · VSL</div>
                <div className="display" style={{fontSize: "32px", lineHeight: "1.1"}}>VIDEO COMING SOON</div>
              </div>
              <button style={{width: "74px", height: "74px", borderRadius: "999px", border: "0", background: "var(--ab-saffron)", color: "#1A0500", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", boxShadow: "var(--glow-saffron)", transition: "transform .15s"}}>
                <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
              </button>
            </div>
            <iframe id="vsl-iframe" src="" allow="autoplay" allowFullScreen style={{position: "absolute", inset: "0", width: "100%", height: "100%", border: "none", display: "none"}}></iframe>
            <div style={{position: "absolute", left: "18px", bottom: "18px"}}>
              <span className="mono" style={{fontSize: "10.5px", letterSpacing: ".1em", color: "var(--ab-ink-2)", background: "rgba(11,9,8,.7)", border: "1px solid var(--ab-line)", padding: "6px 10px", borderRadius: "var(--r-pill)", backdropFilter: "blur(6px)"}}>FROM AMIT BISANI</span>
            </div>
            <div style={{position: "absolute", right: "18px", bottom: "18px"}}>
              <span className="mono" style={{fontSize: "10.5px", letterSpacing: ".1em", color: "var(--course)", background: "rgba(11,9,8,.7)", border: "1px solid rgba(255,91,20,.3)", padding: "6px 10px", borderRadius: "var(--r-pill)", backdropFilter: "blur(6px)"}}>&#9654; WATCH</span>
            </div>
          </div>
          <p style={{textAlign: "center", fontSize: "12.5px", color: "var(--ab-ink-4)", fontFamily: "var(--ab-mono)", letterSpacing: ".08em", marginTop: "14px"}}>3 MINUTES · HOW THE SYSTEM WORKS · WHY IT STICKS</p>
        </div>
      </section>
      
      
      <section className="section" id="reviews">
        <div className="wrap section-head reveal" style={{display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "24px", flexWrap: "wrap"}}>
          <div>
            <div className="eyebrow">/ the proof</div>
            <h2 className="display">Busy people are sceptical.<br/><span className="serif" style={{color: "#FF5B14"}}>Until the day ends and the list is done.</span></h2>
          </div>
          <div style={{textAlign: "right"}}>
            <div style={{fontFamily: "var(--ab-display)", fontSize: "44px", fontWeight: "700", letterSpacing: "-0.02em"}}>4.9 <span style={{color: "var(--ab-saffron)", fontSize: "30px"}}>★</span></div>
            <div style={{fontSize: "13px", color: "var(--ab-ink-3)"}}>averaged across 2,400+ professionals</div>
          </div>
        </div>
      
        <div className="tgrid-wrap reveal">
          <div className="tmarquee row1">
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"By week one the time audit gutted me — <em>11 hours a week</em> in meetings I didn't need to be in. Killed half of them."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-saffron)"}}>RM</div><div><div className="nm">Rohan M.</div><div className="ds">Engineering manager · Bengaluru</div></div></div></div>
            <div className="card wacard">
              <div className="wahead"><div className="avatar" style={{background: "var(--ab-cyan)", width: "32px", height: "32px", fontSize: "12px"}}>SK</div><div><div style={{fontSize: "12.5px", fontWeight: "600"}}>Shilpa K.</div><div style={{fontSize: "10px", color: "var(--ab-good)"}}>online</div></div></div>
              <div className="bubble them">Did the 20-min weekly review for the first time 😅<span className="t">8:42 PM</span></div>
              <div className="bubble them">Walked into Monday actually knowing my week<span className="t">8:42 PM</span></div>
              <div className="bubble me">That's the whole game 🙂<span className="t">8:44 PM</span></div>
            </div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"I'd bought every productivity app going. This is the first thing that told me what to <em>stop</em> doing, not what to add."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-lime)"}}>AV</div><div><div className="nm">Anjali V.</div><div className="ds">Founder · Hyderabad</div></div></div></div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"The 'saying no' scripts alone were worth it. I declined three things this week <em>without</em> the guilt spiral."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-violet)"}}>DT</div><div><div className="nm">Deepak T.</div><div className="ds">Consultant · Delhi NCR</div></div></div></div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"No fluff, no 'wake up at 5am' nonsense. Amit just shows you where the time leaks and how to <em>plug it</em>."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-cyan)"}}>MN</div><div><div className="nm">Meera N.</div><div className="ds">Operations lead · Chennai</div></div></div></div>
          </div>
          <div className="tmarquee row2">
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"I used to end the day exhausted with nothing crossed off. The daily 3-question close <em>fixed that in a week</em>."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-saffron-2)"}}>KP</div><div><div className="nm">Karthik P.</div><div className="ds">Product lead · Kolkata</div></div></div></div>
            <div className="card wacard">
              <div className="wahead"><div className="avatar" style={{background: "var(--ab-saffron)", width: "32px", height: "32px", fontSize: "12px"}}>NJ</div><div><div style={{fontSize: "12.5px", fontWeight: "600"}}>Nikhil J.</div><div style={{fontSize: "10px", color: "var(--ab-good)"}}>online</div></div></div>
              <div className="bubble them">Finished week 4 yesterday<span className="t">6:10 PM</span></div>
              <div className="bubble them">First Friday in years I logged off at 6 with a clear list 🙏<span className="t">6:11 PM</span></div>
              <div className="bubble me">This made my whole week ❤️<span className="t">6:30 PM</span></div>
            </div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"I run a one-person business. 'Drop the system, not the goal' changed how I plan. Fewer tools, more done."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-lime)"}}>PS</div><div><div className="nm">Priya S.</div><div className="ds">Solo operator · Dubai</div></div></div></div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"Calm, practical, evidence-based. Exactly Amit's style from the coaching room. Worth every rupee."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-cyan)"}}>VG</div><div><div className="nm">Vikram G.</div><div className="ds">Sales director · Pune</div></div></div></div>
            <div className="card tcard"><div className="stars">★★★★★</div><div className="q">"'Map energy, not just time' was the line that landed. I stopped scheduling deep work for 4pm. Obvious in hindsight."</div><div className="tperson"><div className="avatar" style={{background: "var(--ab-saffron)"}}>RB</div><div><div className="nm">Ritu B.</div><div className="ds">Designer · Jaipur</div></div></div></div>
          </div>
        </div>
      </section>
      
      
      <section className="section" id="video-reviews">
        <div className="wrap section-head reveal">
          <div className="eyebrow saffron" style={{color: "rgb(255, 91, 20)"}}>/ what they have to say</div>
          <h2 className="display">Don't take our word for it.<br/><span className="serif" style={{color: "#FF5B14"}}>Hear it from the students themselves.</span></h2>
        </div>
      
        <div className="tgrid-wrap reveal" id="vtestimonials">
          <div className="vmarquee vrow1">
            
          </div>
        </div>
      </section>
      
      
      <section className="section" id="problem">
        <div className="wrap">
          <div className="section-head reveal">
            <div className="eyebrow saffron" style={{color: "rgb(255, 91, 20)"}}>/ the problem</div>
            <h2 className="display">Your calendar is full.<br/>Your week is still empty.</h2>
            <p style={{fontSize: "17px", color: "var(--ab-ink-2)", maxWidth: "640px", marginTop: "18px", lineHeight: "1.55"}}>Being busy isn't the same as moving forward. You can answer every message, attend every meeting and clear every notification — and still reach Friday with the one thing that mattered untouched. That gap is quiet, and it compounds.</p>
          </div>
          <div className="pain-grid">
            <div className="card pain reveal"><div className="qmark">“</div><div><h4>"I'm busy all day and finish nothing."</h4><p>Back-to-back from 9 to 7, inbox at zero, and yet the project that actually matters hasn't moved an inch in two weeks.</p></div></div>
            <div className="card pain reveal"><div className="qmark">“</div><div><h4>"My to-do list is where tasks go to die."</h4><p>You've tried every app. The list just gets longer. More tools, more lists, more guilt — and the same things rolling over, day after day.</p></div></div>
            <div className="card pain reveal"><div className="qmark">“</div><div><h4>"I can't say no, so my time isn't mine."</h4><p>Every "quick call" and "can you just" gets a yes. Your week is built from other people's priorities, with no room left for your own.</p></div></div>
            <div className="card pain reveal"><div className="qmark">“</div><div><h4>"I keep putting off the thing that matters."</h4><p>The important work is hard and unscheduled, so it loses — every time — to the urgent, easy, visible stuff that feels like progress.</p></div></div>
            <div className="card pain reveal"><div className="qmark">“</div><div><h4>"I end the day drained and behind."</h4><p>No clear start, no clean finish. Work bleeds into the evening, you never quite switch off, and tomorrow you do it all again.</p></div></div>
          </div>
        </div>
      </section>
      
      
      <section className="section" id="solution">
        <div className="blob" style={{top: "40px", left: "-140px", width: "420px", height: "420px", background: "radial-gradient(circle,rgba(255,91,20,.22),transparent 65%)"}}></div>
        <div className="wrap" style={{position: "relative", zIndex: "1"}}>
          <div className="solution-intro reveal">
            <div>
              <div className="eyebrow">/ the solution</div>
              <h2 className="display" style={{fontSize: "clamp(36px,4.6vw,60px)", marginTop: "12px"}}>Time<br/>Management.</h2>
            </div>
            <div>
              <p style={{fontSize: "18px", color: "var(--ab-ink-2)", lineHeight: "1.6"}}>A four-week system you run <em style={{fontStyle: "italic", fontFamily: "var(--ab-serif)", color: "var(--course)"}}>on</em> your real week — not a fantasy one. Audit where the time goes, drop what doesn't earn its place, design a weekly review, then run a daily close that ends the day clean.</p>
              <p style={{fontSize: "15px", color: "var(--ab-ink-3)", marginTop: "16px", lineHeight: "1.6"}}>No new app to learn. No 5am cold showers. No colour-coded calendar you'll abandon in a week. Just a calm, repeatable system built from what actually worked for 600+ clients.</p>
            </div>
          </div>
      
          <div className="compare reveal">
            <div className="compare-col most">
              <h4>Most productivity advice</h4>
              <div className="crow bad"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Another app to set up, then abandon</div>
              <div className="crow bad"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Adds more to do — never what to drop</div>
              <div className="crow bad"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Hustle theatre — 5am alarms and willpower</div>
              <div className="crow bad"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Generic tips with no system underneath</div>
              <div className="crow bad"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg> Motivation that fades by Wednesday</div>
            </div>
            <div className="compare-col this">
              <h4>Time Management</h4>
              <div className="crow"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> One system you run on your real week</div>
              <div className="crow"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Starts by deciding what to drop</div>
              <div className="crow"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Evidence-based — from 600+ real clients</div>
              <div className="crow"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> A 20-minute weekly review that saves hours</div>
              <div className="crow"><svg className="svgi ci" viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Becomes a habit that runs without you</div>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section optin" id="free-lesson">
        <div className="blob" style={{top: "-80px", right: "-100px", width: "420px", height: "420px", background: "radial-gradient(circle,rgba(255,91,20,.18),transparent 65%)"}}></div>
        <div className="grain"></div>
        <div className="wrap optin-inner" style={{position: "relative", zIndex: "1"}}>
      
          <div className="optin-copy reveal">
            <div className="eyebrow">/ free first lesson</div>
            <h2 className="display headline" style={{marginTop: "12px"}}>Try before you<br/><span className="serif" style={{color: "var(--course)"}}>commit to anything.</span></h2>
            <p className="body">Run the first lesson — completely free. Do the 7-day time audit, see where your week actually goes, and find out whether Amit's no-fluff style clicks for you. No credit card. No catch.</p>
            <div className="optin-perks">
              <div className="optin-perk">Instant access to the full first lesson + worksheet</div>
              <div className="optin-perk">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg>
                A printable time-audit tracker — ready to start tomorrow morning
              </div>
              <div className="optin-perk">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg>
                A short debrief guide so you know exactly what to look for
              </div>
              <div className="optin-perk">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg>
                Zero obligation — unlock the rest only if it earns it
              </div>
            </div>
          </div>
      
          <div className="reveal">
            <div className="opt-form" id="opt-form-wrap">
              <div style={{marginBottom: "24px"}}>
                <div className="eyebrow" style={{color: "rgb(255, 91, 20)"}}>/ get free access</div>
                <div className="display" style={{fontSize: "22px", marginTop: "8px", letterSpacing: "-0.02em"}}>First lesson, on us.</div>
              </div>
      
              <form id="opt-form" style={{display: "flex", flexDirection: "column", gap: "18px"}}>
                <div className="fgrid">
                  <div className="frow">
                    <label>Full Name <span style={{color: "rgb(255, 91, 20)"}}>*</span></label>
                    <input type="text" name="full_name" placeholder="e.g. Priya Sharma" required autoComplete="name" />
                  </div>
                  <div className="frow">
                    <label>Email Address <span style={{color: "rgb(255, 91, 20)"}}>*</span></label>
                    <input type="email" name="email" placeholder="you@example.com" required autoComplete="email" />
                  </div>
                </div>
      
                <div className="frow">
                  <label>Phone — WhatsApp <span style={{color: "rgb(255, 91, 20)"}}>*</span></label>
                  <input type="tel" name="phone" placeholder="+91 98765 43210" required autoComplete="tel" />
                </div>
      
                <div className="frow">
                  <label>Where does your time disappear? <span style={{color: "rgb(255, 91, 20)"}}>*</span></label>
                  <textarea name="challenges" placeholder="e.g. Too many meetings, constant interruptions, can't say no, everything feels urgent, never finish the important work..." required></textarea>
                </div>
      
                <button type="submit" className="btn btn-primary btn-lg btn-block" style={{marginTop: "4px"}}>
                  Get Free Access to the First Lesson
                  <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
                </button>
      
                <p className="fnote" style={{textAlign: "center"}}>
                  <svg className="svgi" style={{width: "12px", height: "12px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l7 4v6c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-4z"/></svg>
                  We respect your privacy. No spam, ever. Your details stay with Amit Bisani only.
                </p>
              </form>
      
              <div className="opt-success" id="opt-success">
                <div className="check">
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg>
                </div>
                <div>
                  <div className="display" style={{fontSize: "22px"}}>You're in!</div>
                  <p style={{fontSize: "14px", color: "var(--ab-ink-2)", marginTop: "10px", lineHeight: "1.6"}}>Check your inbox — Lesson 1 is on its way. Check WhatsApp too; Amit's team will share the audit tracker there. Start tracking tomorrow morning.</p>
                </div>
                <a href="#enrol" className="btn btn-ghost" style={{marginTop: "6px"}}>Explore the full course →</a>
              </div>
            </div>
          </div>
      
        </div>
      </section>
      
      
      <section className="section">
        <div className="wrap">
          <div className="section-head reveal">
            <div className="eyebrow">/ the transformation</div>
            <h2 className="display">Four weeks from now.</h2>
          </div>
          <div className="ba reveal">
            <div className="ba-col now">
              <h4>Where you are now</h4>
              <div className="lead" style={{color: "var(--ab-ink-2)"}}>Busy, behind, drained.</div>
              <ul>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14"/></svg> Full days that add up to nothing</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14"/></svg> A to-do list that only grows</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14"/></svg> Yes to everything, time for nothing</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14"/></svg> The important work always slips</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-ink-4)" strokeWidth="2" strokeLinecap="round"><path d="M5 12h14"/></svg> Work that never quite switches off</li>
              </ul>
            </div>
            <div className="ba-mid"><div className="ba-arrow"><svg className="svgi" style={{width: "20px", height: "20px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div></div>
            <div className="ba-col then">
              <h4>Where you'll be</h4>
              <div className="lead" style={{color: "var(--course)"}}>In control of your week.</div>
              <ul>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Know exactly where your hours go</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> A short list of things that <em style={{fontStyle: "normal", color: "var(--course)"}}>matter</em></li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Say no cleanly, without the guilt</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> The important work gets done first</li>
                <li><svg className="svgi" style={{marginTop: "3px"}} viewBox="0 0 24 24" fill="none" stroke="var(--course)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> End the day clean — and actually log off</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section" id="curriculum">
        <div className="wrap">
          <div className="section-head reveal" style={{display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "24px", flexWrap: "wrap"}}>
            <div>
              <div className="eyebrow">/ what's inside</div>
              <h2 className="display">Nine modules.
      One system you'll keep for life.</h2>
            </div>
            <span className="mono" style={{fontSize: "11px", color: "var(--ab-ink-3)", letterSpacing: ".1em"}}>9 MODULES · 18 LESSONS · WORKSHEETS INCLUDED</span>
          </div>
      
          <div className="acc reveal" id="curriculum-acc">
            <div className="acc-item open">
              <div className="acc-head"><span className="acc-wk">MODULE 01</span><span className="acc-title">Your Time, Your Story</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Time isn't just time — it's your life, the invisible thread tying your dreams, career, relationships and peace of mind together. This module shows how your daily choices compound into your future, the real emotional cost of wasted time, then hunts down the "time thieves" — notifications, doom-scrolling, multitasking — quietly stealing your day.<div className="meta">2 LESSONS · HOW TIME SHAPES YOUR LIFE · YOUR TIME THIEVES</div></div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-wk">MODULE 02</span><span className="acc-title">Master the Map — Planning &amp; Prioritising</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Build the toolkit. Learn to write to-do lists that actually move you forward — the Rule of 3, breaking big tasks into micro-wins — then prioritise like a leader with the Eisenhower Matrix, and turn vague wishes into SMART goals that have deadlines, detail and direction.<div className="meta">3 LESSONS · THE MAGIC OF TO-DO LISTS · THE EISENHOWER MATRIX · SETTING SMART GOALS</div></div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-wk">MODULE 03</span><span className="acc-title">Defeat the Delay Demon — Beating Procrastination</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Procrastination isn't laziness — it's emotional avoidance. Understand the psychology and triggers behind why we delay, then build your personal Anti-Procrastination Toolkit: the Pomodoro technique, focus music, app blockers, smart rewards and the trick of making starting effortless.<div className="meta">3 LESSONS · WHAT IS PROCRASTINATION · WHY WE PROCRASTINATE · YOUR ANTI-PROCRASTINATION TOOLKIT</div></div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-wk">MODULE 04</span><span className="acc-title">Design Your Dream Day</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">A productive day happens by design, not luck. Build an ideal daily routine around your own energy — the golden morning, the 3-3-3 formula, energy rituals and a shutdown routine — then master time blocking: the six zones of a balanced day, batching, and a structure that liberates rather than limits.<div className="meta">3 LESSONS · THE IDEAL DAILY ROUTINE (PARTS A &amp; B) · TIME BLOCKING</div></div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-wk">MODULE 05</span><span className="acc-title">Your Life, Your Blueprint — Real-Life Application</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Bring it all together. Audit where your time really goes, map your life zones, and combine every tool — Pomodoro, Time Blocking, SMART Goals, the Eisenhower Matrix — into one personal plan that balances work, family, health and growth. Then learn to take charge with anchors, energy-aware scheduling and a plan flexible enough for real life.<div className="meta">2 LESSONS · MY TIME MANAGEMENT PLAN · TAKING CHARGE OF YOUR TIME</div></div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-wk">MODULE 06</span><span className="acc-title">Balance = Brilliance — Balanced Living</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Time management is meaningless without a life worth managing it for. Make space for personal growth — hobbies, learning and side passions that fuel everything else — and protect what matters most: real time with family, digital detox, and your health and wellbeing.<div className="meta">2 LESSONS · PERSONAL GROWTH · RELATIONSHIPS &amp; WELLBEING</div></div></div>
            </div>
          </div>
      
          <div className="reveal" style={{display: "flex", justifyContent: "center", marginTop: "34px"}}>
            <a href="#enrol" className="btn btn-primary btn-lg">Enrol &amp; start the audit today <span className="px">· ₹1,499</span> <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
          </div>
        </div>
      </section>
      
      
      <section className="section">
        <div className="wrap instructor">
          <div className="reveal">
            <div className="portrait">
              <svg width="90%" height="90%" viewBox="0 0 100 100" style={{position: "absolute", bottom: "0"}}>
                <path d="M5,100 C12,68 35,62 50,62 C65,62 88,68 95,100 Z" fill="#3A2418"/>
                <path d="M40,68 L40,55 L60,55 L60,68 Z" fill="#3A2418"/>
                <ellipse cx="50" cy="38" rx="20" ry="24" fill="#3A2418"/>
                <path d="M30,32 C30,18 40,12 50,12 C62,12 70,20 70,32 C70,28 65,22 60,22 C60,26 55,28 50,28 C45,28 40,26 40,22 C35,22 30,28 30,32 Z" fill="#0A0606"/>
                <path d="M34,42 C34,52 40,60 50,60 C60,60 66,52 66,42 C64,46 60,48 56,48 C55,52 53,54 50,54 C47,54 45,52 44,48 C40,48 36,46 34,42 Z" fill="#0A0606"/>
                <ellipse cx="50" cy="42" rx="9" ry="2" fill="#0A0606"/>
              </svg>
              <div className="placeholder" style={{position: "absolute", top: "14px", left: "14px", padding: "5px 9px", borderRadius: "var(--r-pill)", background: "rgba(11,9,8,.5)", borderStyle: "solid", borderColor: "rgba(11,9,8,.3)", color: "rgba(11,9,8,.55)"}}>instructor photo</div>
              <div className="badge"><div className="eyebrow muted" style={{fontSize: "9.5px"}}>your coach</div><div style={{fontWeight: "600", marginTop: "3px", fontSize: "13.5px"}}>Amit Bisani · India</div></div>
            </div>
          </div>
          <div className="bio reveal">
            <div className="eyebrow">/ YOUR COACH</div>
            <h2 className="display" style={{fontSize: "clamp(34px,4.2vw,52px)", marginTop: "12px"}}>I'm Amit.<br/><span className="serif" style={{color: "var(--course)"}}>I help you keep your word to yourself.</span></h2>
            <p>My journey began in 2006 — but it was in 2017 that I found my true calling: cracking the code of effective goal-setting, productivity, and time management. I didn't get there by reading theory. I got there by coaching thousands of real people, watching what actually moves the needle, and building a methodology rooted in evidence, not assumption.</p>
            <p>Over the years, that mission has expanded into a wider practice of human transformation. I work on mindset mentoring and relationship coaching, helping people build inner clarity and stronger connections. I train aspiring speakers in the art of public speaking, and I work with children to sharpen critical thinking and communication skills early in life.</p>
            <p>My coaching style fuses inspiration, innovation, and practicality — creating an environment where aspirations aren't just set, but <strong style={{color: "var(--ab-ink)"}}>achieved</strong>.</p>
            <div className="credstats" style={{gridTemplateColumns: "repeat(4,1fr)"}}>
              <div className="cs"><div className="csk">9<span style={{color: "rgb(255, 91, 20)"}}>+</span></div><div className="csl">Years coaching</div></div>
              <div className="cs"><div className="csk">14k<span style={{color: "rgb(255, 91, 20)"}}>+</span></div><div className="csl">Learners impacted</div></div>
              <div className="cs"><div className="csk">20<span style={{color: "rgb(255, 91, 20)"}}>+</span></div><div className="csl">Speaking events</div></div>
              <div className="cs"><div className="csk">4.9<span style={{color: "rgb(255, 91, 20)"}}> ★</span></div><div className="csl">Average rating</div></div>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section" id="enrol">
        <div className="blob" style={{top: "0", right: "-120px", width: "460px", height: "460px", background: "radial-gradient(circle,rgba(255,91,20,.2),transparent 65%)"}}></div>
        <div className="wrap" style={{position: "relative", zIndex: "1"}}>
          <div className="section-head reveal">
            <div className="eyebrow saffron" style={{color: "rgb(255, 91, 20)"}}>/ everything you get</div>
            <h2 className="display">One enrolment.<br/>A whole system.</h2>
          </div>
          <div className="stack">
            <div className="reveal">
              <div className="bonus"><div className="bi"><svg className="svgi" style={{width: "20px", height: "20px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M23 7l-7 5 7 5V7zM2 7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7z"/></svg></div><div className="bt"><div className="bn">The full 4-week course</div><div className="bd">18 lessons · 3 hours of video · lifetime access</div></div><div className="bv">₹1,499</div></div>
              <div className="bonus"><div className="bi"><svg className="svgi" style={{width: "20px", height: "20px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zm0 0a2 2 0 0 1 2-2h13"/></svg></div><div className="bt"><div className="bn">The Weekly Review Workbook</div><div className="bd">3 worksheets: life audit tracker, purpose audit, weekly template</div></div><div className="bv">₹1,499</div></div>
              <div className="bonus"><div className="bi"><svg className="svgi" style={{width: "20px", height: "20px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zm0 0a2 2 0 0 1 2-2h13"/></svg></div><div className="bt"><div className="bn">Bonus eBook · "The 11-Minute Reset"</div><div className="bd">A field guide + 5 audio tracks for the wobbly mid-day</div></div><div className="bv">₹399</div></div>
              <div className="bonus"><div className="bi"><svg className="svgi" style={{width: "20px", height: "20px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></div><div className="bt"><div className="bn">The Finishers' Circle on WhatsApp</div><div className="bd">A calm, moderated group running the same system</div></div><div className="bv">₹1,999</div></div>
            </div>
      
            <div className="card elevated stack-card reveal">
              <div className="chip course" style={{marginBottom: "18px"}}><span className="dot"></span> Founding price · one-time</div>
              <div className="totline"><span>Total real value</span><span className="v">₹5,396</span></div>
              <div className="total">
                <div>
                  <div style={{fontSize: "12px", color: "var(--ab-ink-3)"}} className="mono">YOU PAY TODAY</div>
                  <div className="stack-price">₹1,499</div>
                </div>
                <div className="v">₹5,396</div>
              </div>
              <a href="#" className="btn btn-primary btn-lg btn-block" style={{marginTop: "22px"}}>Enrol now <span className="px">· ₹1,499</span> <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
              <div style={{marginTop: "14px", fontSize: "12px", color: "var(--ab-ink-3)", textAlign: "center", lineHeight: "1.55"}}>UPI · Cards · Net banking · EMI<br/><span style={{color: "var(--ab-ink-2)"}}>Instant access · 30-day money-back guarantee</span></div>
              <div className="rule" style={{margin: "18px 0"}}></div>
              <div style={{display: "flex", gap: "10px", alignItems: "flex-start", fontSize: "12.5px", color: "var(--ab-ink-2)"}}><svg className="svgi" style={{width: "15px", height: "15px", flex: "none", marginTop: "2px"}} viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> <span><strong style={{color: "var(--ab-ink)", fontWeight: "600"}}>For:</strong> working professionals and solo operators whose calendar is full but whose week feels empty.</span></div>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section guarantee">
        <div className="wrap gcard reveal">
          <div className="gseal"><svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l7 4v6c0 5-3.5 8-7 10-3.5-2-7-5-7-10V6l7-4z"/><path d="M9 12l2 2 4-4"/></svg></div>
          <div>
            <div className="eyebrow" style={{color: "var(--ab-lime)"}}>/ zero risk</div>
            <h2 className="display" style={{marginTop: "12px"}}>Run week one. If it doesn't free up a single hour, take your money back.</h2>
            <p>Do the time audit and run the first week on your real schedule. If you don't get hours back — or it's just not for you — email us within 30 days and we'll refund every rupee. No forms, no "why are you leaving" guilt trip. The bonuses are yours to keep.</p>
          </div>
        </div>
      </section>
      
      
      <section className="section" id="faq">
        <div className="wrap">
          <div className="section-head reveal">
            <div className="eyebrow">/ before you ask</div>
            <h2 className="display">The honest answers.</h2>
          </div>
          <div className="acc faq reveal" id="faq-acc">
            <div className="acc-item open">
              <div className="acc-head"><span className="acc-faqn">01</span><span className="acc-title" style={{fontSize: "18px"}}>How much time does the course itself take?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">About 30–45 minutes a week — a few short lessons plus one worksheet you run on your real schedule. It's fully self-paced, so binge a week in one sitting or spread it across a few days. The weekly system it builds takes around 20 minutes a week to run.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">02</span><span className="acc-title" style={{fontSize: "18px"}}>I’ve tried every productivity app. Why is this different?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Because it isn't an app. Most tools add more to track; this starts by deciding what to <em style={{fontStyle: "normal", color: "var(--course)"}}>drop</em>. You run it on paper or in whatever you already use — and it's built from what actually worked for 600+ real clients, not theory.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">03</span><span className="acc-title" style={{fontSize: "18px"}}>I’m not disorganised — I’m just overloaded. Is this for me?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Especially you. This isn't about colour-coding a calendar. It's about auditing where the hours go, cutting what doesn't earn its place, and protecting the work that matters. Overloaded people get the most back.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">04</span><span className="acc-title" style={{fontSize: "18px"}}>Do I have to wake up at 5am or follow a rigid routine?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">No. There's no hustle theatre here — no cold showers, no 5am alarms, no willpower marathons. The whole point is a calm, repeatable system that works around your real life, not against it.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">05</span><span className="acc-title" style={{fontSize: "18px"}}>Will this work if my schedule is chaotic and unpredictable?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Yes — the weekly review and daily close are built for messy weeks. You'll learn to map energy, not just time, and to recover from a blown day without the whole system falling apart. Week four is built entirely around this.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">06</span><span className="acc-title" style={{fontSize: "18px"}}>How does access work? Is it forever?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">One payment, lifetime access — including every future update — on phone, tablet or laptop. Come back and re-run the audit any time your life changes.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">07</span><span className="acc-title" style={{fontSize: "18px"}}>What if it’s not right for me?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Email within 30 days for a full, no-questions refund — and keep the bonuses. Run week one; if it doesn't free up real hours, you pay nothing.</div></div>
            </div>
            <div className="acc-item">
              <div className="acc-head"><span className="acc-faqn">08</span><span className="acc-title" style={{fontSize: "18px"}}>Can I pay in instalments?</span><span className="acc-plus"><svg className="svgi" style={{width: "15px", height: "15px"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg></span></div>
              <div className="acc-body"><div className="inner">Yes — no-cost EMI is available on most cards at checkout, alongside UPI and net banking. International learners can pay by card in USD.</div></div>
            </div>
          </div>
        </div>
      </section>
      
      
      <section className="section urgency">
        <div className="wrap urgband reveal">
          <div>
            <div className="eyebrow saffron" style={{color: "rgb(255, 91, 20)"}}>/ founding cohort</div>
            <h3 className="display" style={{fontSize: "clamp(26px,3vw,38px)", marginTop: "10px"}}>Founding price ends soon.</h3>
            <p style={{fontSize: "14px", color: "var(--ab-ink-3)", marginTop: "10px", maxWidth: "420px"}}>The launch group locks in ₹1,499 <em style={{fontStyle: "normal", color: "var(--ab-ink-2)"}}>and</em> the full bonus stack. After it fills, the price goes up and the Finishers' Circle closes to new members.</p>
            <div className="seats" style={{marginTop: "20px"}}>
              <div className="seatbar"><i style={{backgroundColor: "rgb(255, 91, 20)"}}></i></div>
              <span className="mono" style={{fontSize: "11.5px", color: "var(--ab-ink-2)"}}>39 / 50 seats taken</span>
            </div>
          </div>
          <div style={{textAlign: "center"}}>
            <div className="mono" style={{fontSize: "10.5px", letterSpacing: ".14em", color: "var(--ab-ink-3)", marginBottom: "12px"}}>FOUNDING PRICE ENDS IN</div>
            <div className="countdown" id="countdown">
              <div className="cdcell"><div className="cdn" data-cd="d">02</div><div className="cdl">Days</div></div>
              <div className="cdcell"><div className="cdn" data-cd="h">11</div><div className="cdl">Hours</div></div>
              <div className="cdcell"><div className="cdn" data-cd="m">45</div><div className="cdl">Mins</div></div>
              <div className="cdcell"><div className="cdn" data-cd="s">08</div><div className="cdl">Secs</div></div>
            </div>
            <a href="#enrol" className="btn btn-primary" style={{marginTop: "20px"}}>Lock in ₹1,499 <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
          </div>
        </div>
      </section>
      
      
      <section className="section close">
        <div className="blob" style={{bottom: "-160px", left: "50%", transform: "translateX(-50%)", width: "680px", height: "480px", background: "radial-gradient(circle,rgba(255,91,20,.22),transparent 65%)"}}></div>
        <div className="grain"></div>
        <div className="wrap reveal" style={{position: "relative", zIndex: "1"}}>
          <div className="eyebrow saffron" style={{textAlign: "center", color: "rgb(255, 91, 20)"}}>/ two paths</div>
          <h2 className="display" style={{marginTop: "16px"}}>In four weeks, you'll be<br/>four weeks <span className="serif" style={{color: "#FF5B14"}}>further.</span></h2>
          <p style={{fontSize: "17px", color: "var(--ab-ink-2)", maxWidth: "600px", margin: "20px auto 0", lineHeight: "1.55"}}>The only question is whether you spend them running your week on purpose — or letting it run you. You get to choose that today.</p>
      
          <div className="paths">
            <div className="path a">
              <div className="pl">Path one · do nothing</div>
              <div className="pt">Stay busy, stay behind.</div>
              <p>The meetings keep multiplying. The list keeps growing. Maybe it settles down on its own. Maybe you wonder, later, why you waited.</p>
            </div>
            <div className="path b" style={{borderColor: "rgba(255, 91, 20, 0.3)"}}>
              <div className="pl" style={{color: "rgb(255, 91, 20)"}}>Path two · start this week</div>
              <div className="pt" style={{color: "rgb(255, 91, 20)"}}>Run the system, on purpose.</div>
              <p style={{color: "rgb(255, 91, 20)"}}>Around 30 minutes a week, four weeks, and a way of working that quietly gives you your time back — for good. Starting today.</p>
            </div>
          </div>
      
          <div className="close-cta">
            <a href="#enrol" className="btn btn-primary btn-lg" style={{height: "60px", padding: "0 38px", fontSize: "17px"}}>Enrol in Time Management <span className="px">· ₹1,499</span> <svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
            <a href="#" style={{fontSize: "13.5px", color: "var(--ab-ink-3)", textDecoration: "underline", textUnderlineOffset: "3px"}}>Not sure yet? Book a free 15-min call →</a>
          </div>
      
          <div className="close-trust">
            <span><svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> 30-day money-back guarantee</span>
            <span><svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> Lifetime access · all updates free</span>
            <span><svg className="svgi" viewBox="0 0 24 24" fill="none" stroke="var(--ab-good)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg> 2,400+ professionals · 4.9 ★</span>
          </div>
        </div>
      </section>
      
      
      <footer className="foot">
        <div className="wrap foot-inner">
          <a className="logo" href="#top" style={{opacity: ".9"}}>
            <svg viewBox="0 0 580 351.6" xmlns="http://www.w3.org/2000/svg" style={{height: "22px", width: "auto", display: "block"}}>
              <path fill="#FF5B14" d="M186.43,263.12h-91.46l-12.71,43.04H0L97.99,45.44h87.88l97.97,260.72h-84.36l-13.04-43.04ZM169.72,206.74l-28.78-93.72-28.48,93.72h57.25Z"/>
              <path fill="#FF5B14" d="M309.62,45.44h150.81c25.13,0,44.43,6.22,57.89,18.67,13.46,12.45,20.19,27.86,20.19,46.24,0,15.41-4.8,28.63-14.41,39.66-6.4,7.35-15.77,13.16-28.1,17.43,18.73,4.51,32.51,12.24,41.35,23.21,8.83,10.97,13.25,24.75,13.25,41.35,0,13.52-3.14,25.67-9.43,36.46-6.29,10.79-14.88,19.33-25.79,25.61-6.76,3.91-16.96,6.76-30.59,8.54-18.14,2.37-30.17,3.56-36.1,3.56h-139.07V45.44ZM390.9,147.7h35.03c12.57,0,21.31-2.16,26.23-6.49,4.92-4.33,7.38-10.58,7.38-18.76,0-7.59-2.46-13.52-7.38-17.78-4.92-4.27-13.49-6.4-25.7-6.4h-35.57v49.44ZM390.9,250.14h41.08c13.87,0,23.65-2.46,29.34-7.38,5.69-4.92,8.54-11.53,8.54-19.83,0-7.71-2.82-13.9-8.45-18.58-5.63-4.68-15.5-7.02-29.61-7.02h-40.9v52.82Z"/>
            </svg>
          </a>
          <div className="foot-links">
            <a href="#">Contact</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cancellation &amp; Refund</a>
            <a href="#">Privacy Policy</a>
          </div>
          <div className="mono" style={{fontSize: "10.5px", color: "var(--ab-ink-4)", letterSpacing: ".08em"}}>© 2026 Amit Bisani</div>
        </div>
      </footer>
      
      
      <div className="mbar" id="mbar">
        <div className="mb-t">
          <div className="mb-n">Time Management</div>
          <div className="mb-p">One-time · lifetime access</div>
        </div>
        <a href="#enrol" className="btn btn-primary" style={{height: "42px"}}>Enrol · ₹1,499</a>
      </div>
    </>
  );
}
