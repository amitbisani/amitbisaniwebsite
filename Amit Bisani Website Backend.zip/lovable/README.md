# Time Management — Amit Bisani (React / Vite)

A React port of the Time Management landing page, ready to import into Lovable.

## Run locally
```
npm install
npm run dev
```

## Import into Lovable
1. Push this folder to a GitHub repo.
2. In Lovable: **New Project → Import from GitHub**, and select the repo.

(Lovable's native stack is React + Vite + Tailwind — this project now uses Tailwind.)

## Structure
- `tailwind.config.js` — design tokens live here: colors (`ab-bg`, `ab-saffron`, `course`, …), fonts (`font-display`, `font-serif`, `font-mono`), radii (`rounded-pill`, `rounded-xl`, …) and the `shadow-glow-saffron`. Use these utilities directly in JSX.
- `src/index.css` — Tailwind directives + the component classes (`.btn`, `.card`, `.hero`, …) composed with `@apply`. A few effects Tailwind can't express (keyframes, marquee, masks, pseudo-elements) stay as raw CSS in the `@layer`.
- `src/App.jsx` — the whole page (one component). All interactivity (reveal-on-scroll, accordions, countdown, scroll-spy, video-testimonial uploads, opt-in form, VSL) runs in a single `useEffect`. Ask Lovable to "split App.jsx into section components" to break it up.
- Fonts load from Google Fonts in `index.html`.

## Notes
- Forms and CTAs are front-end only — wire the opt-in form (`window.submitOptIn`) and Enrol buttons to your backend/checkout.
- The VSL and course-trailer are placeholders; set the iframe/video `src` to your embeds.
