/* ============================================================
   editor-bridge.js
   Lives inside the Time Management landing page.
   - Assigns stable ids to blocks + editable fields.
   - Applies saved edits from localStorage on every load (so the page
     reflects CRM changes even when opened standalone).
   - Talks to the Visual Page Editor (parent window) over postMessage
     so every text / image / price / layout change is live + persisted.
   ============================================================ */
(function(){
  "use strict";

  var LS = {
    edits:  'tmlp_edits',    // { ek: {t|h|mix:string} }
    images: 'tmlp_images',   // { ek: dataURL|null }
    layout: 'tmlp_layout',   // { order:[id], hidden:{id:true} }
    price:  'tmlp_price',     // { origToken: currentValue }
    meta:   'tmlp_meta',     // { title, desc }
    css:    'tmlp_css',       // string
    clones: 'tmlp_clones'    // [{id, after, html}]
  };
  function rd(k){ try{ return JSON.parse(localStorage.getItem(k)||'null'); }catch(e){ return null; } }
  function wr(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
  var inEditor = window.parent && window.parent !== window;

  /* ---------------- block detection ---------------- */
  function isBlock(el){
    return el.nodeType===1 && /^(HEADER|SECTION|FOOTER)$/.test(el.tagName) || (el.id==='mbar');
  }
  function blockEls(){
    return Array.prototype.filter.call(document.body.children, function(el){
      if(/^(SCRIPT|TEMPLATE|STYLE)$/.test(el.tagName)) return false;
      if(el.id==='top') return false;
      return isBlock(el);
    });
  }
  var LABELS = [
    ['header.nav','Navigation','nav'],
    ['.hero','Hero','layout'],
    ['#vsl-cover','Sales Video','timer'],     // matched via descendant below
    ['.proofbar','Social Proof','star'],
    ['#reviews','Testimonials','quote'],
    ['#video-reviews','Video Testimonials','quote'],
    ['#problem','The Problem','bulb'],
    ['#solution','The Solution','grid'],
    ['#free-lesson','Free Lesson Opt-in','ticket'],
    ['.ba','Transformation','stack'],
    ['#curriculum','Curriculum','stack'],
    ['.instructor','Instructor','user'],
    ['#enrol','Pricing & Bonuses','ticket'],
    ['.guarantee','Guarantee','shield'],
    ['#faq','FAQ','faq'],
    ['.urgency','Urgency & Countdown','timer'],
    ['.close','Final CTA','rocket'],
    ['footer.foot','Footer','grid'],
    ['#mbar','Sticky Mobile Bar','badge']
  ];
  function labelFor(el){
    for(var i=0;i<LABELS.length;i++){
      var sel=LABELS[i][0];
      if(el.matches(sel) || el.querySelector(sel)) return {label:LABELS[i][1], icon:LABELS[i][2]};
    }
    var h=el.querySelector('h1,h2,h3,h4');
    return {label: h? h.textContent.trim().slice(0,24) : el.tagName.toLowerCase(), icon:'layout'};
  }

  /* ---------------- field detection ---------------- */
  var FIELD_SEL = [
    'h1','h2','h3','h4','h5','h6','p','li','blockquote',
    '.nav-links a','.foot-links a','a.btn','button',
    '.eyebrow','.chip','.tk','.tl','.csk','.csl','.acc-title','.acc-wk','.acc-faqn',
    '.bn','.bd','.bv','.stack-price','.lead','.q','.nm','.ds','.pt','.pl',
    '.mb-n','.mb-p','.tag','.vnm','.vds','.cdl','.totline span','.total .v','.seatbar+span,.seats span'
  ].join(',');
  var INLINE_OK = {SPAN:1,EM:1,STRONG:1,B:1,I:1,A:1,BR:1};

  function longestTextNode(el){
    var best=null,len=-1;
    for(var i=0;i<el.childNodes.length;i++){
      var n=el.childNodes[i];
      if(n.nodeType===3){ var t=n.nodeValue.trim().length; if(t>len){len=t;best=n;} }
    }
    return best;
  }
  function kindOf(el){
    var kids = el.children;
    if(kids.length===0) return 'text';
    var hasSvg=!!el.querySelector('svg'), allInline=true;
    for(var i=0;i<kids.length;i++){ if(!INLINE_OK[kids[i].tagName]){ allInline=false; break; } }
    if(hasSvg) return 'mix';
    if(allInline) return 'rich';
    return 'mix';
  }
  function fieldLabel(el){
    var c=el.classList;
    if(c.contains('eyebrow')) return 'Eyebrow';
    if(c.contains('chip')) return 'Tag';
    if(c.contains('bn')||c.contains('acc-title')||c.contains('lead')||c.contains('nm')||c.contains('vnm')||c.contains('mb-n')) return 'Title';
    if(c.contains('bd')||c.contains('ds')||c.contains('vds')||c.contains('mb-p')) return 'Subtitle';
    if(c.contains('bv')||c.contains('stack-price')) return 'Price';
    if(c.contains('tk')||c.contains('csk')) return 'Stat';
    if(c.contains('tl')||c.contains('csl')||c.contains('cdl')) return 'Stat label';
    if(c.contains('q')) return 'Quote';
    if(c.contains('btn')) return 'Button';
    if(el.tagName==='A') return 'Link';
    if(/^H[1-6]$/.test(el.tagName)) return 'Heading';
    if(el.tagName==='LI') return 'List item';
    if(el.tagName==='P') return 'Paragraph';
    if(el.tagName==='BUTTON') return 'Button';
    return 'Text';
  }
  var PRICE_RE = /₹\s?[\d,]+/;

  function scanLeaves(block){
    var matched = Array.prototype.filter.call(block.querySelectorAll(FIELD_SEL), function(el){
      if(el.closest('a.logo')) return false;
      if(!el.textContent || !el.textContent.trim()) return false;
      // skip second copy of marquee cards (seamless loop duplicates)
      var mq = el.closest('.vmarquee, .tmarquee');
      if(mq){ var cards=mq.children, half=cards.length/2, card=el.closest('.vcard,.tcard,.wacard');
        if(card){ var idx=Array.prototype.indexOf.call(cards,card); if(idx>=half) return false; } }
      return true;
    });
    var set = matched;
    return matched.filter(function(el){
      for(var i=0;i<set.length;i++){ if(set[i]!==el && el.contains(set[i])) return false; }
      return true;
    });
  }

  /* ---------------- assign stable keys ---------------- */
  function assignKeys(){
    blockEls().forEach(function(b,bi){
      if(!b.dataset.block) b.dataset.block = b.id ? 'b-'+b.id : 'blk-'+bi;
      if(!b.dataset.blockLabel){ var L=labelFor(b); b.dataset.blockLabel=L.label; b.dataset.blockIcon=L.icon; }
      var leaves = scanLeaves(b);
      leaves.forEach(function(el,i){ el.dataset.ek = b.dataset.block + '#' + i; });
      // media slots
      var slots = b.querySelectorAll('.video-card .ph.placeholder, .portrait, .placeholder, img[data-editable], .ph');
      var mi=0;
      Array.prototype.forEach.call(slots, function(el){
        if(el.closest('a.logo')) return;
        if(!el.dataset.mk) el.dataset.mk = b.dataset.block + '~' + (mi++);
      });
      // video-testimonial cards (both marquee copies share a slot index)
      Array.prototype.forEach.call(b.querySelectorAll('.vcard'), function(card){
        if(!card.dataset.mk) card.dataset.mk = b.dataset.block + '~v' + (card.dataset.slot||'0');
      });
      // VSL stage (sales video)
      var vslIf=b.querySelector('#vsl-iframe');
      if(vslIf){ var stage=vslIf.parentElement; stage.classList.add('vsl-stage'); if(!stage.dataset.mk) stage.dataset.mk=b.dataset.block+'~vsl'; }
    });
  }

  /* ---------------- apply saved state ---------------- */
  function applyEdits(){
    var e = rd(LS.edits)||{};
    Object.keys(e).forEach(function(ek){
      var el = document.querySelector('[data-ek="'+cssesc(ek)+'"]'); if(!el) return;
      var v=e[ek];
      if(v.t!=null && el.children.length===0) el.textContent=v.t;
      else if(v.h!=null) el.innerHTML=v.h;
      else if(v.mix!=null){ var n=longestTextNode(el); if(n) n.nodeValue=v.mix; }
    });
  }
  function applyImages(){
    var im = rd(LS.images)||{};
    Object.keys(im).forEach(function(mk){ applyMedia(mk, im[mk]); });
  }
  function setImg(el, data){
    if(data){
      if(el.tagName==='IMG'){ el.src=data; }
      else { el.style.backgroundImage='url('+data+')'; el.style.backgroundSize='cover';
        el.style.backgroundPosition='center'; el.classList.add('has-bg'); el.style.color='transparent'; }
    } else {
      if(el.tagName==='IMG'){ el.removeAttribute('src'); }
      else { el.style.backgroundImage=''; el.classList.remove('has-bg'); el.style.color=''; }
    }
  }
  function applyLayout(){
    var lay = rd(LS.layout); if(!lay) return;
    var body=document.body;
    if(lay.order){ var ref=document.querySelector('script'); // keep scripts at end
      lay.order.forEach(function(id){ var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(el && ref) body.insertBefore(el, ref); }); }
    if(lay.hidden){ Object.keys(lay.hidden).forEach(function(id){ if(lay.hidden[id]){ var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(el) el.style.display='none'; } }); }
  }
  function applyPrice(){
    var p = rd(LS.price)||{};
    Object.keys(p).forEach(function(orig){ replacePrice(orig, p[orig]); });
  }
  function replacePrice(orig, val){
    if(orig===val) return;
    var w=document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var n, list=[];
    while((n=w.nextNode())) if(n.nodeValue.indexOf(orig)>-1) list.push(n);
    list.forEach(function(node){ node.nodeValue = node.nodeValue.split(orig).join(val); });
  }
  function applyMeta(){
    var m=rd(LS.meta); if(!m) return;
    if(m.title){ document.title=m.title; }
    if(m.desc!=null){ var md=document.querySelector('meta[name="description"]'); if(!md){ md=document.createElement('meta'); md.name='description'; document.head.appendChild(md); } md.content=m.desc; }
  }
  function applyCss(){
    var c=rd(LS.css); var tag=document.getElementById('tmlp-custom-css');
    if(!tag){ tag=document.createElement('style'); tag.id='tmlp-custom-css'; document.head.appendChild(tag); }
    tag.textContent = (typeof c==='string')? c : '';
  }
  function applyClones(){
    var cl=rd(LS.clones); if(!cl||!cl.length) return;
    cl.forEach(function(c){
      if(document.querySelector('[data-block="'+cssesc(c.id)+'"]')) return;
      var after=document.querySelector('[data-block="'+cssesc(c.after)+'"]');
      var tmp=document.createElement('div'); tmp.innerHTML=c.html;
      var el=tmp.firstElementChild; if(!el) return;
      el.dataset.block=c.id;
      if(after && after.parentNode) after.parentNode.insertBefore(el, after.nextSibling);
      else document.body.appendChild(el);
    });
  }
  function cssesc(s){ return String(s).replace(/["\\]/g,'\\$&'); }

  /* ---------------- build model for editor ---------------- */
  function priceToken(str){ var m=str.match(/₹\s?[\d,]+/); return m? m[0] : null; }
  function buildModel(){
    var blocks = blockEls().map(function(b){
      var fields = scanLeaves(b).map(function(el){
        var k=kindOf(el), val;
        if(k==='rich') val=el.innerHTML.trim();
        else if(k==='mix'){ var n=longestTextNode(el); val=n? n.nodeValue.trim():el.textContent.trim(); }
        else val=el.textContent.trim();
        var isPrice = (k==='text' && PRICE_RE.test(val));
        return { ek:el.dataset.ek, label:fieldLabel(el), kind:isPrice?'price':k, value:val, href: el.tagName==='A'?el.getAttribute('href'):null };
      });
      var seenMk={};
      var media=[];
      Array.prototype.forEach.call(b.querySelectorAll('[data-mk]'), function(el){
        if(seenMk[el.dataset.mk]) return; seenMk[el.dataset.mk]=1;
        if(el.classList.contains('vcard')){
          var nm=el.querySelector('.vnm'); var v=el.querySelector('video');
          media.push({ mk:el.dataset.mk, kind:'video', label:(nm?nm.textContent.trim():'Student video'),
                       hasImg: el.classList.contains('has-video')|| !!(v&&v.src) });
        } else if(el.classList.contains('vsl-stage')){
          media.push({ mk:el.dataset.mk, kind:'vsl', label:'Sales video (VSL)', hasImg: el.classList.contains('has-media') });
        } else {
          media.push({ mk:el.dataset.mk, kind:'image',
                       label: el.classList.contains('portrait')?'Portrait photo':(el.closest('.video-card')?'Trailer image':'Image'),
                       hasImg: !!(el.classList.contains('has-bg')|| (el.tagName==='IMG'&&el.src)) });
        }
      });
      return { id:b.dataset.block, label:b.dataset.blockLabel, icon:b.dataset.blockIcon,
               hidden: b.style.display==='none', fields:fields, media:media,
               rect: rectOf(b) };
    });
    // distinct prices for the Pricing panel
    var priceState = rd(LS.price)||{};
    var seen={}, prices=[];
    blocks.forEach(function(bl){ bl.fields.forEach(function(f){ if(f.kind==='price'){ var tk=priceToken(f.value); if(tk && !seen[tk]){ seen[tk]=1; prices.push({token:tk, value:tk}); } } }); });
    // include any tokens we've already remapped (original->current)
    Object.keys(priceState).forEach(function(orig){ if(!seen[priceState[orig]]){ seen[priceState[orig]]=1; prices.push({token:orig, value:priceState[orig]}); } });
    return { blocks:blocks, docHeight: document.documentElement.scrollHeight,
             meta: rd(LS.meta)||{title:document.title, desc:(document.querySelector('meta[name=description]')||{}).content||''},
             css: rd(LS.css)||'', prices: dedupePrices(prices, priceState) };
  }
  function dedupePrices(prices, state){
    // map current display value for each original token
    return prices.map(function(p){ return { token:p.token, value: state[p.token]!=null? state[p.token] : p.token }; });
  }
  function rectOf(el){ var r=el.getBoundingClientRect(); return { top:r.top+window.scrollY, left:r.left+window.scrollX, width:r.width, height:r.height }; }

  /* ---------------- mutations ---------------- */
  function setField(ek, kind, value){
    var el=document.querySelector('[data-ek="'+cssesc(ek)+'"]'); if(!el) return;
    var e=rd(LS.edits)||{};
    if(kind==='rich'){ el.innerHTML=value; e[ek]={h:value}; }
    else if(kind==='mix'){ var n=longestTextNode(el); if(n) n.nodeValue=value; e[ek]={mix:value}; }
    else { el.textContent=value; e[ek]={t:value}; }
    wr(LS.edits,e);
  }
  function setHref(ek, href){
    var el=document.querySelector('[data-ek="'+cssesc(ek)+'"]'); if(!el||el.tagName!=='A') return;
    el.setAttribute('href',href);
    var e=rd(LS.edits)||{}; e[ek]=e[ek]||{}; e[ek].href=href; wr(LS.edits,e);
  }
  function applyMedia(mk, data){
    var els=document.querySelectorAll('[data-mk="'+cssesc(mk)+'"]'); if(!els.length) return;
    var first=els[0];
    if(first.classList.contains('vcard')){
      Array.prototype.forEach.call(els, function(card){
        var v=card.querySelector('video'); if(!v) return;
        if(data){ v.src=data; card.classList.add('has-video'); }
        else { v.removeAttribute('src'); card.classList.remove('has-video','playing'); }
      });
      return;
    }
    if(first.classList.contains('vsl-stage')){
      var cover=first.querySelector('#vsl-cover'), ifr=first.querySelector('#vsl-iframe'), vid=first.querySelector('video.vsl-vid');
      if(!data){ if(vid)vid.remove(); if(ifr){ifr.src='';ifr.style.display='none';} if(cover)cover.style.display=''; first.classList.remove('has-media'); return; }
      if(cover) cover.style.display='none';
      if(typeof data==='string' && data.slice(0,4)==='url:'){
        if(vid) vid.remove();
        if(ifr){ ifr.src=embedUrl(data.slice(4)); ifr.style.display='block'; }
      } else {
        if(ifr) ifr.style.display='none';
        if(!vid){ vid=document.createElement('video'); vid.className='vsl-vid'; vid.controls=true; vid.playsInline=true;
          vid.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000;z-index:5;'; first.appendChild(vid); }
        vid.src=data;
      }
      first.classList.add('has-media'); return;
    }
    Array.prototype.forEach.call(els, function(el){ setImg(el, data); });
  }
  function embedUrl(u){
    var m=u.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{6,})/);
    if(m) return 'https://www.youtube.com/embed/'+m[1];
    var vm=u.match(/vimeo\.com\/(\d+)/); if(vm) return 'https://player.vimeo.com/video/'+vm[1];
    return u;
  }
  function setImage(mk, data){
    applyMedia(mk, data);
    var els=document.querySelectorAll('[data-mk="'+cssesc(mk)+'"]');
    if(els[0] && els[0].classList.contains('vcard')){
      var slot=els[0].dataset.slot||'0';
      try{ if(data) localStorage.setItem('tm_vtest_'+slot, data); else localStorage.removeItem('tm_vtest_'+slot); }catch(e){}
      return;
    }
    var im=rd(LS.images)||{}; if(data) im[mk]=data; else delete im[mk]; wr(LS.images,im);
  }
  function setBlockHidden(id, hidden){
    var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(!el) return;
    el.style.display = hidden? 'none':'';
    var lay=rd(LS.layout)||{}; lay.hidden=lay.hidden||{}; if(hidden) lay.hidden[id]=true; else delete lay.hidden[id]; wr(LS.layout,lay);
  }
  function reorder(order){
    var body=document.body, ref=document.querySelector('script');
    order.forEach(function(id){ var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(el&&ref) body.insertBefore(el,ref); });
    var lay=rd(LS.layout)||{}; lay.order=order; wr(LS.layout,lay);
  }
  function duplicateBlock(id){
    var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(!el) return;
    var clone=el.cloneNode(true);
    var nid='dup-'+Date.now();
    clone.removeAttribute('id'); clone.dataset.block=nid;
    // strip child ek/mk so they get reassigned uniquely
    Array.prototype.forEach.call(clone.querySelectorAll('[data-ek]'), function(n){ n.removeAttribute('data-ek'); });
    Array.prototype.forEach.call(clone.querySelectorAll('[data-mk]'), function(n){ n.removeAttribute('data-mk'); });
    el.parentNode.insertBefore(clone, el.nextSibling);
    var cl=rd(LS.clones)||[]; cl.push({id:nid, after:id, html:clone.outerHTML}); wr(LS.clones,cl);
  }
  function deleteBlock(id){
    var el=document.querySelector('[data-block="'+cssesc(id)+'"]'); if(!el) return;
    // if it's a clone, remove entirely; else just hide (so it can be restored)
    var cl=rd(LS.clones)||[]; var ci=cl.findIndex(function(c){return c.id===id;});
    if(ci>-1){ cl.splice(ci,1); wr(LS.clones,cl); el.remove(); }
    else setBlockHidden(id,true);
  }
  function setPrice(orig, value){
    // track current value per original token
    var state=rd(LS.price)||{};
    var prev = state[orig]!=null? state[orig] : orig;
    replacePrice(prev, value);
    state[orig]=value; wr(LS.price,state);
  }
  function setMeta(title, desc){
    var m=rd(LS.meta)||{}; if(title!=null)m.title=title; if(desc!=null)m.desc=desc; wr(LS.meta,m); applyMeta();
  }
  function setCss(v){ wr(LS.css, v); applyCss(); }
  function resetAll(){ [LS.edits,LS.images,LS.layout,LS.price,LS.meta,LS.css,LS.clones].forEach(function(k){ localStorage.removeItem(k); }); for(var i=0;i<8;i++){ localStorage.removeItem('tm_vtest_'+i); } location.reload(); }

  /* ---------------- message handling ---------------- */
  function reply(){ if(inEditor) window.parent.postMessage({src:'tmlp', t:'model', model:buildModel()}, '*'); }
  function onMsg(ev){
    var d=ev.data; if(!d||d.to!=='tmlp') return;
    switch(d.t){
      case 'model': reply(); return;
      case 'set': setField(d.ek,d.kind,d.value); break;
      case 'href': setHref(d.ek,d.value); break;
      case 'img': setImage(d.mk,d.data); break;
      case 'blockHidden': setBlockHidden(d.id,d.hidden); break;
      case 'reorder': reorder(d.order); break;
      case 'dup': duplicateBlock(d.id); break;
      case 'del': deleteBlock(d.id); break;
      case 'price': setPrice(d.orig,d.value); break;
      case 'meta': setMeta(d.title,d.desc); break;
      case 'css': setCss(d.value); break;
      case 'reset': resetAll(); return;
      case 'rescan': assignKeys(); break;
    }
    reply();
  }

  /* ---------------- init ---------------- */
  function init(){
    assignKeys();
    applyClones();
    assignKeys();      // re-key after clones inserted
    applyEdits();
    applyImages();
    applyPrice();
    applyLayout();
    applyMeta();
    applyCss();
    // restore hrefs
    var e=rd(LS.edits)||{}; Object.keys(e).forEach(function(ek){ if(e[ek]&&e[ek].href){ var el=document.querySelector('[data-ek="'+cssesc(ek)+'"]'); if(el) el.setAttribute('href',e[ek].href); } });
    window.addEventListener('message', onMsg);
    if(inEditor){
      document.documentElement.classList.add('in-editor','fieldhint');
      document.addEventListener('click', function(ev){
        var f=ev.target.closest('[data-ek]'), m=ev.target.closest('[data-mk]');
        var hit=f||m; if(!hit) return;
        ev.preventDefault(); ev.stopPropagation();
        var blk=hit.closest('[data-block]');
        window.parent.postMessage({src:'tmlp', t:'focus', ek:(f?f.dataset.ek:null), mk:(m?m.dataset.mk:null), block:blk?blk.dataset.block:null}, '*');
      }, true);
      reply();
    }
    window.addEventListener('load', function(){ setTimeout(reply, 300); });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
