# Visual Page Editor

A lightweight, CRM-style visual editor for the **Amit Bisani** course landing pages.
Edit text, links, images, prices, and section order on a live landing page — no code,
no rebuild. Every change is written to `localStorage`, so the page reflects edits even
when opened on its own.

![Visual Page Editor](https://img.shields.io/badge/build-static-success) ![No build step](https://img.shields.io/badge/build%20step-none-blue) ![Vanilla JS](https://img.shields.io/badge/stack-vanilla%20JS-yellow)

---

## ⚡️ No build step. No Tailwind. No bundler.

This is the first thing to know before you import the repo anywhere:

- **There is no Tailwind, PostCSS, Vite, Webpack, or npm install.** The editor and the
  landing page are hand-written HTML + CSS (plain CSS custom properties / variables) +
  vanilla JavaScript. Nothing is transpiled or compiled.
- **You do not run `npm install` or `npm run build`.** There is no `package.json`,
  no `tailwind.config.js`, no `node_modules`. Cloning the repo gives you the finished site.
- The only runtime dependencies are **web fonts** loaded over a CDN (see below).

> If you came here expecting a Tailwind config to wire up — there isn't one, and you don't
> need one. A separate React/Vite/Tailwind port of the landing page lives elsewhere in the
> parent project (`lovable/`, `handoff/`); that is **not** what this editor uses or needs.

---

## Run it locally

Because browsers block `file://` iframes and `postMessage` in some cases, serve the folder
over HTTP rather than double-clicking `index.html`. Any static server works:

```bash
# Python 3
python3 -m http.server 8080

# Node (npx, no install)
npx serve .

# PHP
php -S localhost:8080
```

Then open <http://localhost:8080/> — `index.html` is the editor.

---

## Deploy it

It's a static site, so it deploys anywhere that serves files:

- **GitHub Pages** — push to `main`, then Settings → Pages → deploy from `main` / root.
  The editor is `index.html`, so the site root *is* the editor.
- **Netlify / Vercel / Cloudflare Pages** — point at the repo, leave the build command
  **empty**, set the publish directory to the repo root (`/`).
- **Any S3 bucket / nginx / Apache** — copy the files in. Done.

No environment variables, no secrets, no server runtime.

---

## What's in the repo

```
visual-page-editor/
├── index.html                    # The editor shell (open this)
├── editor-app.js                 # Editor controller — left panel, inspector, undo/redo, modals
├── editor-bridge.js              # Runs inside the landing page; applies edits, talks to the editor
├── time-management-landing.html  # The landing page being edited (loads editor-bridge.js)
├── README.md
├── LICENSE
└── .gitignore
```

### How the pieces talk

```
┌─────────────────────────────────────────────┐
│ index.html  (the editor)                     │
│   editor-app.js                              │
│                                              │
│   ┌──────────────────────────────────────┐  │
│   │ <iframe> time-management-landing.html │  │   postMessage
│   │   editor-bridge.js  ◄─────────────────┼──┼──►  (live, two-way)
│   └──────────────────────────────────────┘  │
└─────────────────────────────────────────────┘
```

- `editor-bridge.js` scans the landing page, assigns stable IDs to every editable block
  and field, and exposes a model to the editor over `postMessage`.
- `editor-app.js` renders that model into the block list + inspector and posts changes back.
- The bridge persists every change to `localStorage` under the `tmlp_*` keys, then re-applies
  them on the next load — so the standalone landing page shows the saved state too.

---

## Web font dependencies (the only external thing)

Both `index.html` and the landing page pull fonts from two CDNs:

| Font | Source |
|------|--------|
| Manrope, JetBrains Mono, Bricolage Grotesque, Instrument Serif | Google Fonts (`fonts.googleapis.com`) |
| Geist | Fontshare (`api.fontshare.com`) |

These load fine on any online deployment. **If you need the site to work fully offline**,
download the font files and replace the two `<link>` tags in `index.html` and
`time-management-landing.html` with local `@font-face` rules. Everything else is already local.

---

## Using the editor

- **Left panel** — every section of the page as a draggable block. Drag to reorder,
  click the eye to hide/show, click a block to select it.
- **Center** — a live preview. Click any text or image directly on the page to jump
  straight to its field.
- **Right inspector** — *Content* tab edits text, links, prices, and media for the
  selected block; *Block* tab reorders / duplicates / hides / deletes it.
- **Page Settings** (left, bottom) — page title, SEO meta, global Pricing find-and-replace,
  Custom CSS injection, and **Reset all edits**.
- **Undo / redo** in the top bar (snapshots of the saved state).
- **Reset all edits** restores the original page (clears the `tmlp_*` localStorage keys).

### Adding another landing page to the editor

The editor currently drives one page (`time-management-landing.html`). To wire up another:

1. Add `<script src="editor-bridge.js"></script>` just before `</body>` of the new page.
2. Point the iframe in `index.html` at it: `<iframe class="frame" id="frame" src="your-page.html" ...>`.
3. If you want both pages selectable, extend the page picker in `index.html` / `editor-app.js`
   to swap the iframe `src`. The bridge's block/field detection is generic and works on any
   page using the same section structure and class names.

---

## License

MIT — see [LICENSE](./LICENSE).
