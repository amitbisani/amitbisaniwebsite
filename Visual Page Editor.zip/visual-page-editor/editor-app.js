/* ============================================================
   editor-app.js  —  Visual Page Editor controller
   Drives the Time Management landing page (in the iframe) through
   the editor-bridge postMessage protocol. Everything here is live
   and persisted: text, links, images, prices, layout, settings.
   ============================================================ */
(function(){
"use strict";

/* ---------- icons ---------- */
const ICONS = {
  layout:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
  bulb:'<path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.1V18h6v-1.2c0-.8.4-1.6 1-2.1A7 7 0 0 0 12 2z"/>',
  star:'<path d="M12 2l3 6.5 7 .9-5 4.8 1.3 7-6.3-3.4L5.7 21 7 14.2 2 9.4l7-.9z"/>',
  quote:'<path d="M7 7h4v4a4 4 0 0 1-4 4M13 7h4v4a4 4 0 0 1-4 4"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  shield:'<path d="M12 2l8 3v6c0 5-3.5 8-8 11-4.5-3-8-6-8-11V5z"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  stack:'<path d="M12 2l9 5-9 5-9-5z"/><path d="M3 12l9 5 9-5M3 17l9 5 9-5"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  ticket:'<path d="M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2 2 2 0 0 0 0 4 2 2 0 0 1-2 2H5a2 2 0 0 1-2-2 2 2 0 0 0 0-4z"/>',
  badge:'<circle cx="12" cy="9" r="6"/><path d="M9 14l-1 8 4-2 4 2-1-8"/>',
  faq:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 4 1.5c0 1.5-2 2-2 3.5M12 17h.01"/>',
  timer:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M9 2h6"/>',
  rocket:'<path d="M5 13c-1.5 1.5-2 5-2 5s3.5-.5 5-2M9 11a8 8 0 0 1 9-9 8 8 0 0 1-9 9zM12 8a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/>',
  nav:'<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M3 12h18M3 18h12"/>'
};
const ic = (k,sz=14)=>`<svg class="svgi" viewBox="0 0 24 24" style="width:${sz}px;height:${sz}px">${ICONS[k]||ICONS.layout}</svg>`;
const $ = s=>document.querySelector(s);
const esc = s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

/* ---------- elements ---------- */
const frame=$('#frame'), frameWrap=$('#frameWrap'), center=$('#center'),
      canvas=$('#canvas'), selOverlay=$('#selOverlay'), selTagName=$('#selTagName'),
      blocksEl=$('#blocks'), inspBody=$('#inspBody'), inspTitle=$('#inspTitle'),
      tabsEl=$('#tabs'), fileInput=$('#fileInput'), modalRoot=$('#modalRoot'), toastEl=$('#toast');

/* ---------- state ---------- */
let model=null, selId=null, tab='content', suppress=false, pendingMedia=null, pendingFocus=null;

/* ---------- messaging ---------- */
function fwin(){ try{ return frame.contentWindow; }catch(e){ return null; } }
function post(msg){ const w=fwin(); if(w) w.postMessage(Object.assign({to:'tmlp'},msg),'*'); }
function requestModel(){ post({t:'model'}); }

window.addEventListener('message', ev=>{
  const d=ev.data; if(!d||d.src!=='tmlp') return;
  if(d.t==='model') onModel(d.model);
  else if(d.t==='focus'){ pendingFocus=d.ek; if(selId!==d.block){ selId=d.block; renderAll(); } else focusField(d.ek); }
});

function onModel(m){
  model=m;
  if(!selId || !m.blocks.some(b=>b.id===selId)) selId = m.blocks[0] && m.blocks[0].id;
  frame.style.height = Math.max(600,m.docHeight)+'px';
  if(!restoring) pushHistory();
  if(suppress){ return; }              // user is typing — don't blow away focus
  renderAll();
}
function renderAll(){ renderBlocks(); renderInspector(); positionOverlay(); if(pendingFocus){ focusField(pendingFocus); pendingFocus=null; } }

/* ---------- left: block list ---------- */
const eyeOpen='<svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>';
const eyeOff ='<svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><path d="M9.9 4.2A9.5 9.5 0 0 1 12 4c6.5 0 10 8 10 8a13 13 0 0 1-2.3 3M6 6.5C3.5 8.2 2 12 2 12s3.5 7 10 7a9 9 0 0 0 3.4-.6M3 3l18 18"/></svg>';
function renderBlocks(){
  if(!model) return;
  blocksEl.innerHTML='';
  model.blocks.forEach((b,i)=>{
    const el=document.createElement('div');
    el.className='block'+(b.id===selId?' sel':'')+(b.hidden?' hidden-blk':'');
    el.draggable=true; el.dataset.id=b.id;
    el.innerHTML=`<span class="bicon">${ic(b.icon,15)}</span><span class="bnum">${String(i+1).padStart(2,'0')}</span><span class="bname">${esc(b.label)}</span>`+
      `<span class="eye" data-eye title="Show / hide">${b.hidden?eyeOff:eyeOpen}</span>`;
    el.addEventListener('click',e=>{ if(e.target.closest('[data-eye]')){ toggleHidden(b.id); return; } select(b.id); });
    blocksEl.appendChild(el);
  });
  attachDnd();
}
function select(id){ selId=id; renderBlocks(); renderInspector(); scrollToBlock(id); positionOverlay(); }
function toggleHidden(id){ const b=model.blocks.find(x=>x.id===id); post({t:'blockHidden',id,hidden:!b.hidden}); }

/* drag reorder */
let dragId=null;
function attachDnd(){
  [...blocksEl.children].forEach(el=>{
    el.addEventListener('dragstart',e=>{dragId=el.dataset.id; el.classList.add('dragging'); e.dataTransfer.effectAllowed='move';});
    el.addEventListener('dragend',()=>{el.classList.remove('dragging'); clearMarks();});
    el.addEventListener('dragover',e=>{e.preventDefault(); clearMarks(); const r=el.getBoundingClientRect(); el.classList.add(e.clientY>r.top+r.height/2?'drop-after':'drop-before');});
    el.addEventListener('drop',e=>{
      e.preventDefault();
      const order=model.blocks.map(b=>b.id);
      const from=order.indexOf(dragId); const r=el.getBoundingClientRect();
      let to=order.indexOf(el.dataset.id)+(e.clientY>r.top+r.height/2?1:0);
      const moved=order.splice(from,1)[0]; if(from<to)to--; order.splice(to,0,moved);
      post({t:'reorder',order});
    });
  });
}
function clearMarks(){[...blocksEl.children].forEach(c=>c.classList.remove('drop-before','drop-after'));}

/* ---------- center: overlay + scroll ---------- */
function curBlock(){ return model && model.blocks.find(b=>b.id===selId); }
function positionOverlay(){
  const b=curBlock(); if(!b||!b.rect||b.hidden){ selOverlay.style.display='none'; return; }
  selOverlay.style.display='block';
  selOverlay.style.top=b.rect.top+'px';
  selOverlay.style.height=Math.max(20,b.rect.height)+'px';
  selTagName.textContent=b.label;
}
function scrollToBlock(id){
  const b=model.blocks.find(x=>x.id===id); if(!b||!b.rect) return;
  const wrapTop = frameWrap.getBoundingClientRect().top - center.getBoundingClientRect().top + center.scrollTop;
  center.scrollTo({top: Math.max(0, wrapTop + b.rect.top - 90), behavior:'smooth'});
}

/* ---------- right: inspector ---------- */
tabsEl.addEventListener('click',e=>{const t=e.target.closest('.tab'); if(!t)return; tab=t.dataset.tab; [...tabsEl.children].forEach(c=>c.classList.toggle('active',c===t)); renderInspector();});
inspBody.addEventListener('focusin',e=>{ if(e.target.matches('input,textarea')) suppress=true; });
inspBody.addEventListener('focusout',e=>{ if(e.target.matches('input,textarea')){ suppress=false; } });

function renderInspector(){
  const b=curBlock(); if(!b){ inspBody.innerHTML=''; return; }
  inspTitle.textContent=b.label;
  $('#blockVis').classList.toggle('on', !b.hidden);
  if(tab==='content') inspBody.innerHTML = contentForm(b);
  else inspBody.innerHTML = blockForm(b);
  wireInspector(b);
}

function fieldControl(f){
  const id=`fld-${f.ek}`;
  if(f.kind==='price')
    return `<input class="inp priceinp" data-ek="${f.ek}" data-kind="text" id="${id}" value="${esc(f.value)}" />`;
  if(f.kind==='rich')
    return `<textarea class="ta" data-ek="${f.ek}" data-kind="rich" id="${id}" rows="2">${esc(f.value)}</textarea>`;
  if(f.kind==='mix')
    return `<input class="inp" data-ek="${f.ek}" data-kind="mix" id="${id}" value="${esc(f.value)}" />`;
  return (f.value.length>54 || /\n/.test(f.value))
    ? `<textarea class="ta" data-ek="${f.ek}" data-kind="text" id="${id}" rows="3">${esc(f.value)}</textarea>`
    : `<input class="inp" data-ek="${f.ek}" data-kind="text" id="${id}" value="${esc(f.value)}" />`;
}
function contentForm(b){
  let h='';
  if(!b.fields.length && !b.media.length)
    return `<div class="empty-state"><div class="es-ic">${ic('layout',26)}</div><p>This block has no editable text or media. Use the <b>Block</b> tab to reorder, hide or duplicate it.</p></div>`;
  b.fields.forEach(f=>{
    h+=`<div class="field-card ${f.kind==='price'?'price':''}">`+
       `<div class="fc-head"><span class="fc-kind">${f.kind==='price'?'₹ price':f.kind}</span><span class="fc-label">${esc(f.label)}</span></div>`+
       fieldControl(f);
    if(f.href!=null)
      h+=`<div class="linkrow"><label class="lbl" style="margin:9px 0 5px">Link</label><input class="inp" data-href="${f.ek}" value="${esc(f.href)}" /></div>`;
    h+=`</div>`;
  });
  if(b.media.length){
    h+=`<div class="divider"></div><p class="sublabel">Media</p>`;
    b.media.forEach(md=>{
      if(md.kind==='vsl'){
        h+=`<div class="fld"><label class="lbl">${esc(md.label)}</label>`+
           `<div class="media-prev thumb ${md.hasImg?'filled':''}">${md.hasImg?'✓ sales video set':'No video yet'}</div>`+
           `<div class="media-actions"><button class="btn btn-ghost" data-upload="${md.mk}" data-mkkind="video">Upload video file</button>`+
           (md.hasImg?`<button class="btn btn-ghost" data-removeimg="${md.mk}">Remove</button>`:'')+`</div>`+
           `<div class="linkrow"><label class="lbl" style="margin:10px 0 5px">…or paste an embed URL</label>`+
           `<div class="row"><input class="inp" data-vslurl="${md.mk}" placeholder="YouTube / Vimeo / .mp4 link"/>`+
           `<button class="gearbtn" data-vslgo="${md.mk}" title="Apply URL"><svg class="svgi" viewBox="0 0 24 24" style="width:15px;height:15px;stroke-width:2.5"><path d="M20 6L9 17l-5-5"/></svg></button></div></div></div>`;
        return;
      }
      const isVid=md.kind==='video';
      h+=`<div class="fld"><label class="lbl">${esc(md.label)}${isVid?' · video':''}</label>`+
         `<div class="media-prev thumb ${md.hasImg?'filled':''}" data-mkprev="${md.mk}">${md.hasImg?(isVid?'✓ video uploaded':''):(isVid?'No video':'No image')}</div>`+
         `<div class="media-actions"><button class="btn btn-ghost" data-upload="${md.mk}" data-mkkind="${md.kind||'image'}">${md.hasImg?'Replace':'Upload'} ${isVid?'video':'image'}</button>`+
         (md.hasImg?`<button class="btn btn-ghost" data-removeimg="${md.mk}">Remove</button>`:'')+`</div></div>`;
    });
  }
  return h;
}
function blockForm(b){
  return `
  <label class="check ${b.hidden?'':'on'}" id="visToggle"><span class="box"><svg class="svgi" viewBox="0 0 24 24" style="width:12px;height:12px;stroke-width:3"><path d="M20 6L9 17l-5-5"/></svg></span>Visible on the page</label>
  <div class="divider"></div>
  <p class="sublabel">Arrange</p>
  <div class="section-actions">
    <button class="btn btn-ghost" data-move="up"><svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><path d="M12 19V5M5 12l7-7 7 7"/></svg>Move up</button>
    <button class="btn btn-ghost" data-move="down"><svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><path d="M12 5v14M5 12l7 7 7-7"/></svg>Move down</button>
  </div>
  <div class="section-actions">
    <button class="btn btn-ghost" data-act="dup"><svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>Duplicate</button>
    <button class="btn btn-ghost" data-act="del" style="color:var(--saffron)"><svg class="svgi" viewBox="0 0 24 24" style="width:14px;height:14px"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>${b.hidden?'Delete':'Hide'}</button>
  </div>
  <div class="divider"></div>
  <div class="fld"><label class="lbl">Block ID (anchor)</label><input class="inp" value="${esc(b.id)}" readonly style="color:var(--ink-3)" /></div>`;
}

function wireInspector(b){
  // live text bind
  inspBody.querySelectorAll('[data-ek]').forEach(inp=>{
    inp.addEventListener('input',()=>post({t:'set',ek:inp.dataset.ek,kind:inp.dataset.kind,value:inp.value}));
  });
  inspBody.querySelectorAll('[data-href]').forEach(inp=>{
    inp.addEventListener('input',()=>post({t:'href',ek:inp.dataset.href,value:inp.value}));
  });
  // media
  inspBody.querySelectorAll('[data-upload]').forEach(btn=>btn.addEventListener('click',()=>{ pendingMedia=btn.dataset.upload; fileInput.accept=btn.dataset.mkkind==='video'?'video/*':'image/*'; fileInput.value=''; fileInput.click(); }));
  inspBody.querySelectorAll('[data-removeimg]').forEach(btn=>btn.addEventListener('click',()=>post({t:'img',mk:btn.dataset.removeimg,data:null})));
  inspBody.querySelectorAll('[data-vslgo]').forEach(btn=>btn.addEventListener('click',()=>{
    const inp=[...inspBody.querySelectorAll('[data-vslurl]')].find(i=>i.dataset.vslurl===btn.dataset.vslgo);
    if(inp&&inp.value.trim()){ post({t:'img',mk:btn.dataset.vslgo,data:'url:'+inp.value.trim()}); toast('Sales video set'); }
  }));
  // block tab
  const vt=$('#visToggle'); if(vt) vt.addEventListener('click',()=>toggleHidden(b.id));
  inspBody.querySelectorAll('[data-move]').forEach(btn=>btn.addEventListener('click',()=>moveBlock(b.id,btn.dataset.move)));
  inspBody.querySelectorAll('[data-act]').forEach(btn=>btn.addEventListener('click',()=>{
    if(btn.dataset.act==='dup') post({t:'dup',id:b.id});
    else post({t:'del',id:b.id});
  }));
}
function moveBlock(id,dir){
  const order=model.blocks.map(b=>b.id); const i=order.indexOf(id); const j=dir==='up'?i-1:i+1;
  if(j<0||j>=order.length) return; order.splice(i,1); order.splice(j,0,id); post({t:'reorder',order});
}
function focusField(ek){
  const el=inspBody.querySelector(`#fld-${CSS.escape(ek)}`); if(el){ el.focus(); el.scrollIntoView({block:'center'}); }
}

/* inspector header buttons */
$('#inspDup').addEventListener('click',()=>{ if(selId) post({t:'dup',id:selId}); });
$('#inspDel').addEventListener('click',()=>{ if(selId) post({t:'del',id:selId}); });
$('#blockVis').addEventListener('click',()=>{ if(selId) toggleHidden(selId); });

/* ---------- media upload ---------- */
fileInput.addEventListener('change',()=>{
  const f=fileInput.files&&fileInput.files[0]; if(!f||!pendingMedia) return;
  const rd=new FileReader();
  rd.onload=()=>{ post({t:'img',mk:pendingMedia,data:rd.result}); pendingMedia=null; };
  rd.readAsDataURL(f);
});

/* ---------- add block ---------- */
const addBtn=document.querySelector('.addblock');
if(addBtn) addBtn.addEventListener('click',()=>{ if(selId) post({t:'dup',id:selId}); toast('Block added below selection'); });

/* ---------- device preview ---------- */
$('#devices').addEventListener('click',e=>{
  const d=e.target.closest('.dev'); if(!d)return;
  [...document.querySelectorAll('.dev')].forEach(x=>x.classList.toggle('active',x===d));
  canvas.className='canvas'+(d.dataset.dev==='desktop'?'':' '+d.dataset.dev);
  selOverlay.style.display='none';
  setTimeout(requestModel,420);    // widths reflow -> remeasure rects
});

/* ---------- topbar ---------- */
$('#previewBtn').addEventListener('click',()=>window.open(frame.getAttribute('src'),'_blank'));
$('#save').addEventListener('click',function(){
  const o=this.textContent; this.textContent='Saved ✓'; $('#savedago').textContent='just now';
  toast('Page saved — changes are live'); setTimeout(()=>this.textContent=o,1500);
});
$('#undo').addEventListener('click',undo);
$('#redo').addEventListener('click',redo);

/* ---------- page settings ---------- */
document.querySelectorAll('.setrow[data-set]').forEach(row=>row.addEventListener('click',()=>openSetting(row.dataset.set)));
function openSetting(kind){
  if(!model) return;
  if(kind==='general'){
    openModal('General','<div class="fld"><label class="lbl">Page title</label><input class="inp" id="m-title" value="'+esc(model.meta.title)+'"/></div>',
      ()=>{ post({t:'meta',title:$('#m-title').value}); toast('Saved'); });
  } else if(kind==='seo'){
    openModal('SEO Settings',
      '<div class="fld"><label class="lbl">Meta title</label><input class="inp" id="m-title" value="'+esc(model.meta.title)+'"/></div>'+
      '<div class="fld"><label class="lbl">Meta description</label><textarea class="ta" id="m-desc" rows="3">'+esc(model.meta.desc||'')+'</textarea></div>',
      ()=>{ post({t:'meta',title:$('#m-title').value,desc:$('#m-desc').value}); toast('Saved'); });
  } else if(kind==='pricing'){
    let body='<p style="font-size:12.5px;color:var(--ink-3);margin:0 0 14px;line-height:1.5">Change a price here and it updates everywhere it appears on the page.</p>';
    if(!model.prices.length) body+='<div class="empty-state"><p>No prices detected on the page.</p></div>';
    model.prices.forEach((p,i)=>{ body+='<div class="fld"><label class="lbl">'+esc(p.token)+'</label><input class="inp priceinp" data-orig="'+esc(p.token)+'" value="'+esc(p.value)+'"/></div>'; });
    openModal('Pricing',body,()=>{
      modalRoot.querySelectorAll('[data-orig]').forEach(inp=>{ if(inp.value!==inp.dataset.orig) post({t:'price',orig:inp.dataset.orig,value:inp.value}); });
      toast('Prices updated');
    });
  } else if(kind==='css'){
    openModal('Custom CSS','<div class="fld"><label class="lbl">CSS injected into the page</label><textarea class="ta code" id="m-css" rows="8" placeholder="/* e.g. */\n.hero h1{ letter-spacing:-.04em; }">'+esc(model.css||'')+'</textarea></div>',
      ()=>{ post({t:'css',value:$('#m-css').value}); toast('CSS applied'); });
  } else if(kind==='reset'){
    openModal('Reset all edits','<p style="font-size:13.5px;color:var(--ink-2);line-height:1.6">This clears every change made in the editor — text, images, prices, layout and settings — and restores the original page. This cannot be undone.</p>',
      ()=>{ post({t:'reset'}); toast('Reset — reloading'); }, 'Reset everything');
  }
}
function openModal(title,bodyHTML,onSave,saveLabel){
  modalRoot.innerHTML=
    '<div class="modal"><div class="modal-head"><h3>'+esc(title)+'</h3>'+
    '<button class="iconbtn" id="m-x"><svg class="svgi" viewBox="0 0 24 24" style="width:16px;height:16px"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>'+
    '<div class="modal-body">'+bodyHTML+'</div>'+
    '<div class="modal-foot"><button class="btn btn-ghost" id="m-cancel">Cancel</button><button class="btn btn-primary" id="m-save">'+(saveLabel||'Save')+'</button></div></div>';
  modalRoot.style.display='grid';
  const close=()=>{ modalRoot.style.display='none'; modalRoot.innerHTML=''; };
  modalRoot.addEventListener('click',e=>{ if(e.target===modalRoot) close(); },{once:true});
  $('#m-x').onclick=close; $('#m-cancel').onclick=close;
  $('#m-save').onclick=()=>{ onSave&&onSave(); close(); };
}

/* ---------- toast ---------- */
let toastT;
function toast(msg){ toastEl.innerHTML='<span class="dot"></span>'+esc(msg); toastEl.classList.add('show'); clearTimeout(toastT); toastT=setTimeout(()=>toastEl.classList.remove('show'),2200); }

/* ---------- undo / redo (snapshots of bridge localStorage) ---------- */
const KEYS=['tmlp_edits','tmlp_images','tmlp_layout','tmlp_price','tmlp_meta','tmlp_css','tmlp_clones'];
let hist=[], redoStack=[], restoring=false;
function ls(){ try{ return fwin().localStorage; }catch(e){ return null; } }
function snapshot(){ const s=ls(); if(!s) return null; const o={}; KEYS.forEach(k=>o[k]=s.getItem(k)); return JSON.stringify(o); }
function pushHistory(){ const snap=snapshot(); if(snap==null) return; if(hist.length && hist[hist.length-1]===snap) return; hist.push(snap); if(hist.length>40)hist.shift(); redoStack=[]; updateUndo(); }
function restore(snap){ const s=ls(); if(!s||snap==null) return; const o=JSON.parse(snap); KEYS.forEach(k=>{ if(o[k]==null) s.removeItem(k); else s.setItem(k,o[k]); }); restoring=true; frame.contentWindow.location.reload(); }
function undo(){ if(hist.length<2) return; redoStack.push(hist.pop()); restore(hist[hist.length-1]); updateUndo(); }
function redo(){ if(!redoStack.length) return; const s=redoStack.pop(); hist.push(s); restore(s); updateUndo(); }
function updateUndo(){ $('#undo').disabled=hist.length<2; $('#redo').disabled=!redoStack.length; }
updateUndo();

/* reset restoring flag once reloaded model comes back */
const _onModel=onModel;
window.addEventListener('message',ev=>{ if(ev.data&&ev.data.src==='tmlp'&&ev.data.t==='model'&&restoring){ restoring=false; } });

/* ---------- boot ---------- */
frame.addEventListener('load',()=>{ setTimeout(requestModel,200); });
setTimeout(requestModel,500);
})();
